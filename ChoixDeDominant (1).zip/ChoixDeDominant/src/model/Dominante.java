package model;
 
/**
* Classe Dominante
* Représente une dominante avec son identifiant, nom et quota.
*
* @author yangzhen
* @version 1.0
*/
public class Dominante {
    private int id_dominante;
    private String nomDomi;
    private int quota;
    private String sigle;
    private int quotaapp;
 
    // Constructeur
    public Dominante(int id_dominante, String nomDomi, int quota, String sigle,int quotaapp) {
        this.id_dominante = id_dominante;
        this.nomDomi = nomDomi;
        this.quota = quota;
        this.sigle = sigle;
        this.quotaapp = quotaapp;
    }
 
    // Getters et Setters
    public int getQuotaApp() {
        return quotaapp;
    }
    
    public void setQuotaApp(int quotaapp) {
        this.quotaapp = quotaapp;
    }
    
    
    public int getId_dominante() {
        return id_dominante;
    }
 
    public void setId_dominante(int id_dominante) {
        this.id_dominante = id_dominante;
    }
 
    public String getNomDomi() {
        return nomDomi;
    }
 
    public void setNomDomi(String nomDomi) {
        this.nomDomi = nomDomi;
    }
 
    public int getQuota() {
        return quota;
    }
 
    public void setQuota(int quota) {
        this.quota = quota;
    }
    
    public String getSigle() {
        return sigle;
    }
 
    public void setSigle(String nomDomi) {
        this.sigle = sigle;
    }
    public boolean peutAccepter() {
        return quota > 0;
    }

    public void incrementerApprenti() {
        if (quota > 0) quota--;
    }

    public void incrementerClassique() {
        if (quota > 0) quota--;
    }

    public void decrementerPlace() {
        quota++;
    }
    
   
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Dominante)) return false;
        Dominante that = (Dominante) o;
        return this.id_dominante == that.id_dominante;
    }

   
    public int hashCode() {
        return Integer.hashCode(id_dominante);
    }


  

 
    public String toString() {
        return nomDomi;
    }
}
 
 
 