package model;

/**
 * Classe Authentification
 * @author yangzhen
 * @version 1.0
 * */
public class Authentification {
	/** 
	 * reference du administrateur
	 */
	private int id_au;		
	/**
	 * nom
	 */
	private String compte;	
	/**
	 * prenom
	 */
	private String motdepasse;		
	/**
	 * reference
	 */

	//private ArrayList<Article> listArticles;

	/**
	 * Constructor
	 * @param id identifiant du Authentification
	 * @param compte
	 * @param motdepasse
	 */
	public Authentification(int id_au, String compte, String motdepasse) {
		this.id_au= id_au;
		this.compte = compte;
		this.motdepasse = motdepasse;
		
	}
	
	/**
	 * getter pour l'attribut reference
	 * @return valeur de la reference admini
	 */
	public int getId_au() {
		return id_au;
	}
	/**
	 * getter pour l'attribut compte
	 * @return valeur du compte
	 */
	public String getCompte() {
		return compte;
	}

	
	/**
	 * getter pour l'attribut motdepasse
	 * @return valeur de motdepasse
	 */
	public String getMotdepasse() {
		return motdepasse;
	}
	/**
	 * setter pour l'attribut motdepasse
	 * @param prenom : nouvelle valeur de motdepasse
	 */
	public void setMotdepasse(String motdepasse) {
		this.motdepasse = motdepasse;
	}
	
	
	/**
	 * Redefinition de la methode toString permettant de definir la traduction de l'objet en String
	 * pour l'affichage dans la console par exemple
	 */
	@Override
	public String toString() {
		return "Authentification [ref : " + id_au + ", " + compte
				+ ", " + motdepasse + "]";
	}
}
