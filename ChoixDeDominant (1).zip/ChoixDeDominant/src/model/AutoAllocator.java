package model;

import dao.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;

/**
 * Classe responsable de l'allocation automatique des étudiants aux différentes dominantes.
 * <p>
 * Les étudiants apprentis doivent choisir 2 dominantes, les étudiants classiques 5. Chaque étudiant ne peut
 * être affecté qu'à une seule dominante, selon la priorité de ses choix, son classement de 1re année,
 * et les quotas disponibles pour chaque type (apprenti / classique). Les étudiants sans choix sont
 * automatiquement affectés à une dominante disposant de places disponibles.
 * </p>
 *
 * @author Wu Yufan
 */
public class AutoAllocator {

    public String performAllocation() {
        StringBuilder journal = new StringBuilder();

        EtudiantDAO etudiantDAO = new EtudiantDAO();
        DominanteDAO dominanteDAO = new DominanteDAO();
        AttributionDAO attributionDAO = new AttributionDAO();

        // Nettoyer les anciennes attributions automatiques
        attributionDAO.clearAllAttributions();

        List<Etudiant> tousEtudiants = etudiantDAO.getAllEtudiants();
        List<Dominante> toutesDominantes = dominanteDAO.getAll();

        Map<String, Integer> nomVersId = new HashMap<>();
        for (Dominante d : toutesDominantes) {
            nomVersId.put(d.getNomDomi(), d.getId_dominante());
        }

        Map<String, Integer> quotaTotal = dominanteDAO.getQuotaTotal();
        Map<String, Integer> quotaApp = dominanteDAO.getQuotaApprenti();
        Map<String, Integer> quotaAppRestant = new HashMap<>(quotaApp);
        Map<String, Integer> quotaClassiqueRestant = new HashMap<>();

        for (String nom : quotaTotal.keySet()) {
            int total = quotaTotal.getOrDefault(nom, 0);
            int apprenti = quotaApp.getOrDefault(nom, 0);
            quotaClassiqueRestant.put(nom, Math.max(0, total - apprenti));
        }

        List<Etudiant> apprentis = new ArrayList<>();
        List<Etudiant> classiques = new ArrayList<>();
        List<Etudiant> sansChoix = new ArrayList<>();

        for (Etudiant e : tousEtudiants) {
            if (attributionDAO.hasSubmittedChoix(e.getId_etudiant())) {
                if ("apprentissage".equalsIgnoreCase(e.getType())) {
                    apprentis.add(e);
                } else {
                    classiques.add(e);
                }
            } else {
                sansChoix.add(e);
            }
        }

        // Affectation automatique des étudiants sans choix
        journal.append("🔸 Attribution des étudiants sans choix...\n");
        for (Etudiant e : sansChoix) {
            Map<String, Integer> cible = "apprentissage".equalsIgnoreCase(e.getType()) ? quotaAppRestant : quotaClassiqueRestant;
            boolean affecte = false;
            for (String nom : cible.keySet()) {
                if (cible.get(nom) > 0) {
                    attributionDAO.assignEtudiantToDominanteWithOrdre(e.getId_etudiant(), nomVersId.get(nom), 0);
                    cible.put(nom, cible.get(nom) - 1);
                    journal.append("✅ ").append(e.getNom()).append(" affecté automatiquement à ").append(nom).append("\n");
                    affecte = true;
                    break;
                }
            }
            if (!affecte) {
                journal.append("❌ ").append(e.getNom()).append(" non affecté (aucune place disponible)\n");
            }
        }

        // Attribution des apprentis
        journal.append("\n🔹 Attribution des étudiants apprentis (2 choix max)...\n");
        for (Etudiant e : apprentis) {
            e.setChoixDominantes(etudiantDAO.getChoixDominantesPourEtudiant(e.getId_etudiant()));
        }
        attribuerSelonPriorite(apprentis, 2, quotaAppRestant, nomVersId, journal, attributionDAO, "Apprenti");

        // Attribution des classiques
        journal.append("\n🔹 Attribution des étudiants classiques (5 choix max)...\n");
        for (Etudiant e : classiques) {
            e.setChoixDominantes(etudiantDAO.getChoixDominantesPourEtudiant(e.getId_etudiant()));
        }
        attribuerSelonPriorite(classiques, 5, quotaClassiqueRestant, nomVersId, journal, attributionDAO, "Classique");

        attributionDAO.deleteOriginalChoix();
        journal.append("\n✅ Attribution automatique terminée.\n");

        return journal.toString();
    }

    private void attribuerSelonPriorite(List<Etudiant> etudiants,
                                        int nbChoixMax,
                                        Map<String, Integer> quotaRestant,
                                        Map<String, Integer> nomVersId,
                                        StringBuilder journal,
                                        AttributionDAO attributionDAO,
                                        String label) {

        etudiants.sort(Comparator.comparingInt(Etudiant::getClassement));

        for (Etudiant e : etudiants) {
            List<Dominante> choix = e.getChoixDominantes();
            boolean assigne = false;

            for (int i = 0; i < Math.min(choix.size(), nbChoixMax); i++) {
                Dominante d = choix.get(i);
                String nom = d.getNomDomi();
                int idDom = d.getId_dominante();

                if (quotaRestant.getOrDefault(nom, 0) > 0) {
                    attributionDAO.assignEtudiantToDominanteWithOrdre(e.getId_etudiant(), idDom, 0);
                    quotaRestant.put(nom, quotaRestant.get(nom) - 1);
                    journal.append("✅ ").append(label).append(" ").append(e.getNom())
                           .append(" affecté à ").append(nom)
                           .append(" (choix ").append(i + 1).append(")\n");
                    assigne = true;
                    break;
                }
            }

            if (!assigne) {
                journal.append("❌ ").append(label).append(" ").append(e.getNom())
                       .append(" non affecté (tous choix saturés)\n");
            }
        }
    }
}
