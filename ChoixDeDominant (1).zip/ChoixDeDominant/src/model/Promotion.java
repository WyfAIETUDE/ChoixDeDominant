package model;

/**
 * Représente une promotion avec un identifiant, un nom et un état.
 */
public class Promotion {
    private int id;
    private String nom;
    private String etat;

    /**
     * Constructeur pour initialiser une promotion.
     * 
     * @param id Identifiant unique de la promotion.
     * @param nom Nom de la promotion.
     * @param etat État actuel de la promotion.
     */
    public Promotion(int id, String nom, String etat) {
        this.id = id;
        this.nom = nom;
        this.etat = etat;
    }

    /**
     * Retourne l'identifiant de la promotion.
     * 
     * @return identifiant.
     */
    public int getId() { 
    	return id; 
    	}

    /**
     * Retourne le nom de la promotion.
     * 
     * @return nom.
     */
    public String getNom() { 
    	return nom;
    	}

    /**
     * Retourne l'état de la promotion.
     * 
     * @return état.
     */
    public String getEtat() { 
    	return etat;
    	}

    /**
     * Modifie l'identifiant de la promotion.
     * 
     * @param id nouvel identifiant.
     */
    public void setId(int id) {
    	this.id = id; 
    	}

    /**
     * Modifie le nom de la promotion.
     * 
     * @param nom nouveau nom.
     */
    public void setNom(String nom) { 
    	this.nom = nom; 
    	}

    /**
     * Modifie l'état de la promotion.
     * 
     * @param etat nouvel état.
     */
    public void setEtat(String etat) { 
    	this.etat = etat; 
    	}

    /**
     * Retourne une représentation textuelle de la promotion.
     * 
     * @return chaîne sous la forme "nom (état)".
     */
    @Override
    public String toString() {
        return nom + " (" + etat + ")";
    }
}
