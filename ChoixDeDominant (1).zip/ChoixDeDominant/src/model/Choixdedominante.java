package model;

/**
 * Représente un choix de dominante effectué par un étudiant.
 * 
 * <p>
 * Chaque instance correspond à un choix d'une dominante avec un ordre de préférence
 * pour un étudiant donné.
 * </p>
 * @author YANG Zhen
 */
public class Choixdedominante {

    /**
     * Identifiant unique du choix.
     */
    private int idChoix;

    /**
     * Identifiant de la dominante choisie.
     */
    private int idChoixdomDom;

    /**
     * Ordre de classement (préférence) du choix parmi les différentes dominantes sélectionnées.
     */
    private int ordreClassement;

    /**
     * Identifiant de l'étudiant ayant effectué ce choix.
     */
    private int idChoixEtu;

    /**
     * Constructeur sans argument.
     */
    public Choixdedominante() {
    }

    /**
     * Constructeur avec paramètres pour initialiser un choix de dominante.
     * 
     * @param idChoix Identifiant unique du choix.
     * @param idChoixdomDom Identifiant de la dominante choisie.
     * @param ordreClassement Ordre de préférence de ce choix.
     * @param idChoixEtu Identifiant de l'étudiant.
     */
    public Choixdedominante(int idChoix, int idChoixdomDom, int ordreClassement, int idChoixEtu) {
        this.idChoix = idChoix;
        this.idChoixdomDom = idChoixdomDom;
        this.ordreClassement = ordreClassement;
        this.idChoixEtu = idChoixEtu;
    }

    /**
     * Retourne l'identifiant unique du choix.
     * 
     * @return l'id du choix.
     */
    public int getIdChoix() {
        return idChoix;
    }

    /**
     * Définit l'identifiant unique du choix.
     * 
     * @param idChoix nouvel identifiant du choix.
     */
    public void setIdChoix(int idChoix) {
        this.idChoix = idChoix;
    }

    /**
     * Retourne l'identifiant de la dominante choisie.
     * 
     * @return l'id de la dominante choisie.
     */
    public int getIdChoixdomDom() {
        return idChoixdomDom;
    }

    /**
     * Définit l'identifiant de la dominante choisie.
     * 
     * @param idChoixdomDom nouvel id de la dominante.
     */
    public void setIdChoixdomDom(int idChoixdomDom) {
        this.idChoixdomDom = idChoixdomDom;
    }

    /**
     * Retourne l'ordre de classement (préférence) du choix.
     * 
     * @return l'ordre de préférence.
     */
    public int getOrdreClassement() {
        return ordreClassement;
    }

    /**
     * Définit l'ordre de classement (préférence) du choix.
     * 
     * @param ordreClassement nouvel ordre de préférence.
     */
    public void setOrdreClassement(int ordreClassement) {
        this.ordreClassement = ordreClassement;
    }

    /**
     * Retourne l'identifiant de l'étudiant ayant fait ce choix.
     * 
     * @return l'id de l'étudiant.
     */
    public int getIdChoixEtu() {
        return idChoixEtu;
    }

    /**
     * Définit l'identifiant de l'étudiant ayant fait ce choix.
     * 
     * @param idChoixEtu nouvel id de l'étudiant.
     */
    public void setIdChoixEtu(int idChoixEtu) {
        this.idChoixEtu = idChoixEtu;
    }

    /**
     * Retourne une représentation sous forme de chaîne de caractères de l'objet Choixdedominante.
     * 
     * @return une chaîne décrivant l'objet.
     */
    @Override
    public String toString() {
        return "Choixdedominante{" +
                "idChoix=" + idChoix +
                ", idChoixdomDom=" + idChoixdomDom +
                ", ordreClassement=" + ordreClassement +
                ", idChoixEtu=" + idChoixEtu +
                '}';
    }
}

