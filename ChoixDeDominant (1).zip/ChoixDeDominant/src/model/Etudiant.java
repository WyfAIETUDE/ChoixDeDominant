package model;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

/**
 * Représente un étudiant avec ses informations personnelles et ses choix de dominantes.
 * @author YANG Zhen/WU Yuan
 * @version 1.0
 */
public class Etudiant {
    private int id_etudiant;           
    private String nom;         
    private String prenom;     
    private int idPromotion;   
    private int classement;     
    private String type;        
    private int idEtudAu;      
    private LocalDate naissance;
    private List<Dominante> choixDominantes = new ArrayList<>();
    
    
    /**
     * Constructeur sans argument.
     */
    public Etudiant() {
    }

    /**
     * Constructeur avec paramètres pour initialiser un étudiant.
     * 
     * @param id_etudiant Identifiant de l'étudiant.
     * @param nom Nom de famille.
     * @param prenom Prénom.
     * @param naissance Date de naissance.
     * @param idPromotion Identifiant de la promotion.
     * @param classement Classement de l'étudiant.
     * @param type Filière ou type d'étudiant.
     * @param idEtudAu Identifiant d'un autre attribut étudiant (au besoin).
     */
    public Etudiant(int id_etudiant, String nom, String prenom, LocalDate naissance, int idPromotion, int classement, String type, int idEtudAu) {
        this.id_etudiant = id_etudiant;
        this.nom = nom;
        this.prenom = prenom;
        this.idPromotion = idPromotion;
        this.classement = classement;
        this.type = type;
        this.idEtudAu = idEtudAu;
        this.naissance = naissance;
    }

    // Getters et Setters

    public int getId_etudiant() {
        return id_etudiant;
    }

    public void setId_etudiant(int id_etudiant) {
        this.id_etudiant = id_etudiant;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getIdPromotion() {
        return idPromotion;
    }

    public void setIdPromotion(int idPromotion) {
        this.idPromotion = idPromotion;
    }

    public int getClassement() {
        return classement;
    }

    public void setClassement(int classement) {
        this.classement = classement;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getIdEtudAu() {
        return idEtudAu;
    }
    public void setChoixDominantes(List<Dominante> choixDominantes) {
        this.choixDominantes = choixDominantes;
    }

    public void setIdEtudAu(int idEtudAu) {
        this.idEtudAu = idEtudAu;
    }
    
    public LocalDate getNaissance() {
        return naissance;
    }

    public void setNaissance(LocalDate naissance) {
        this.naissance = naissance;
    }
    
    /**
     * Retourne la filière de l'étudiant.
     * 
     * @return la filière.
     */
    public String getFiliere() {
        return this.type;
    }

    /**
     * Retourne la liste des choix de dominantes de l'étudiant.
     * 
     * @return liste des dominantes choisies.
     */
    public List<Dominante> getChoixDominantes() {
        return choixDominantes;
    }

    /**
     * Ajoute une dominante aux choix de l'étudiant.
     * 
     * @param d la dominante à ajouter.
     */
    public void ajouterChoix(Dominante d) {
        choixDominantes.add(d);
    }

    /**
     * Retire une dominante des choix de l'étudiant.
     * 
     * @param d la dominante à retirer.
     */
    public void retirerChoix(Dominante d) {
        choixDominantes.remove(d);
    }

    /**
     * Valide les choix de l'étudiant.
     * 
     * @return true si les choix sont valides, false sinon.
     *         (Actuellement toujours true, possibilité d'ajouter une logique de validation)
     */
    public boolean validerChoix() {
        return true; // Ou ajoutez une logique de validation selon la date ou autre critère
        }
    }


