package model;

/**
 * Classe Administrateur
 * @author yangzhen
 * @version 1.0
 * */
public class Administrateur {
	/** 
	 * reference du administrateur
	 */
	private int id_admini;		
	/**
	 * nom
	 */
	private String nom;	
	/**
	 * prenom
	 */
	private String prenom;		
	/**
	 * reference
	 */
	private int id_ad_au;
	/**
	 * liste d'articles
	 */
	private String taper;

	/**
	 * Constructor
	 * @param id identifiant du administrateur
	 * @param nom
	 * @param prenom
	 * @param id etranger
	 */
	public Administrateur(int id_admini, String nom, String prenom, int id_ad_au) {
		this.id_admini= id_admini;
		this.nom = nom;
		this.prenom = prenom;
		this.id_ad_au = id_ad_au;
		
	}
	
	/**
	 * getter pour l'attribut reference
	 * @return valeur de la reference admini
	 */
	public int getId_admini() {
		return id_admini;
	}
	
	public int setId_admini(int id_admini) {
		return this.id_admini = id_admini;
	}
	/**
	 * getter pour l'attribut nom
	 * @return valeur du nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * setter pour l'attribut name
	 * @param name : nouvelle valeur du nom du admini
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * getter pour l'attribut prenom
	 * @return valeur de prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * setter pour l'attribut prenom
	 * @param prenom : nouvelle valeur de prenom
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	/**
	 * getter pour l'attribut id_ad_au
	 * @return valeur de reference
	 */
	public int getId_ad_au() {
		return id_ad_au;
	}
	/**
	 * setter pour l'attribut email
	 * @param qteStock : nouvelle valeur de l'adresse mail
	 */
	public void setId_ad_au(int id_ad_au) {
		this.id_ad_au= id_ad_au;
	}




	/**
	 * Redefinition de la methode toString permettant de definir la traduction de l'objet en String
	 * pour l'affichage dans la console par exemple
	 */
	@Override
	public String toString() {
		return "Administrateur [ref : " + id_admini + ", " + nom
				+ ", " + prenom + ", " + id_ad_au + "]";
	}
}
