package gui;

import dao.DominanteDAO;
import model.Dominante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Fenêtre indépendante affichant les informations des places par dominante :
 * Dominante (nom), Places Totales (quotaApp), Places Occupees (toujours 0)
 * 
 * @author YANG zhen
 */
public class StatutPlacesAppGUI extends JFrame {

    /** 
     * Table utilisée pour afficher les données des dominantes.
     */
    private JTable table;

    /**
     * Modèle de table contenant les données (colonnes : Dominante, Places Totales, Places Occupees).
     */
    private DefaultTableModel model;

    /**
     * DAO (Data Access Object) utilisé pour récupérer les données des dominantes depuis la base.
     */
    private DominanteDAO dao = new DominanteDAO();

    /**
     * Constructeur : initialise la fenêtre et son contenu.
     */
    public StatutPlacesAppGUI() {
        setTitle("Statut des Places App");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Centrer la fenêtre

        model = new DefaultTableModel(new Object[]{"Dominante", "Places Totales", "Places Occupees"}, 0);
        table = new JTable(model);

        loadData();

        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    /**
     * Charge les données depuis la table dominante.
     * Utilise quotaApp comme Places Totales, et met Places Occupees à 0.
     */
    private void loadData() {
        model.setRowCount(0);
        List<Dominante> list = dao.getAll();

        for (Dominante d : list) {
            String nom = d.getNomDomi();
            int quotaApp = d.getQuotaApp();
            int placesOccupees = 0;

            model.addRow(new Object[]{nom, quotaApp, placesOccupees});
        }
    }

    /**
     * Point d'entrée pour lancer la fenêtre indépendamment.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StatutPlacesAppGUI().setVisible(true);
        });
    }
}

