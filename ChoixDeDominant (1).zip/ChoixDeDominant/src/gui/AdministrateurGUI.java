package gui;

import javax.swing.*;
import model.AutoAllocator;

import javax.swing.table.DefaultTableModel;

import dao.AdministrateurDAO;
import dao.AuthentificationDAO;
import model.Administrateur;
import model.Authentification;
import dao.AttributionDAO;
import java.util.List;
import java.util.Map;
import dao.*;
import model.Etudiant;

import java.awt.*;

/**
 * Classe de l'interface graphique dédiée à l'administrateur.
 * Cette interface permet :
 * - la gestion des promotions et dominantes
 * - le lancement de l’attribution automatique
 * - la consultation des répartitions des étudiants
 * - la gestion des comptes administrateurs
 * - l'affichage des préférences des étudiants
 * 
 * Cette interface s'affiche dans une fenêtre principale avec plusieurs onglets.
 * 
 * @author YANG Zhen / WU Yufan
 * @version 1.0
 */
public class AdministrateurGUI extends JFrame {

    /**
     * Constructeur principal de l'interface administrateur.
     * Initialise les composants de l'interface graphique.
     */
    public AdministrateurGUI() {
        setTitle("Interface Administrateur");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Gestion des promotions
        tabbedPane.addTab("Gestion des promotion", new PromotionGUI());

        // Gestion des dominantes
        tabbedPane.addTab("Gestion dominante", new DominanteGUI());

        // Lancement de l’attribution automatique
        tabbedPane.addTab("Attribution automatique", createAllocationPanel());

        // Vue globale de la répartition
        tabbedPane.addTab("Vue d'ensemble de la répartition", createOverviewPanel());

        // Vue des choix étudiants
        tabbedPane.addTab("choix de etudiant", createStudentPreferencePanel());

        // Gestion des informations administrateurs
        tabbedPane.addTab("Gestion des administrateurs", createAdminInfoPanel());
        
        tabbedPane.addTab("Tous les choix initiaux", createAllStudentChoixPanel());


        add(tabbedPane);
    }

    /**
     * Crée un panneau pour effectuer une attribution automatique des étudiants.
     * @return JPanel avec un bouton d’exécution et une zone de log
     */
    
    
    private JPanel createAllocationPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JTextArea logArea = new JTextArea(15, 50);
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton allocateButton = new JButton("Effectuer une allocation automatique");
        allocateButton.addActionListener(e -> {
            AutoAllocator allocator = new AutoAllocator();
            String result = allocator.performAllocation();  
            logArea.setText(result);
            JOptionPane.showMessageDialog(panel, "Attribution terminée.");
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(allocateButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }
    /**
     * Crée un panneau affichant tous les choix initiaux des étudiants,
     * en distinguant apprentis et classiques.
     */
    private JPanel createAllStudentChoixPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton showFinalButton = new JButton("Afficher les résultats finaux");
        buttonPanel.add(showFinalButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        AttributionDAO dao = new AttributionDAO();
        EtudiantDAO etuDAO = new EtudiantDAO();
        List<Etudiant> allEtudiants = etuDAO.getAllEtudiants();

        // Afficher les choix initiaux (déjà fait ci-dessus)
        StringBuilder sb = new StringBuilder();
        sb.append("=====  Étudiants apprentis =====\n");
        for (Etudiant e : allEtudiants) {
            if ("apprentissage".equalsIgnoreCase(e.getType())) {
                List<String> choix = dao.getStudentChoixById(e.getId_etudiant());
                sb.append("• ").append(e.getNom()).append(" ").append(e.getPrenom()).append("\n");
                for (String ch : choix) {
                    sb.append("   ").append(ch).append("\n");
                }
                if (choix.isEmpty()) sb.append("   (Aucun choix soumis)\n");
                sb.append("\n");
            }
        }

        sb.append("\n=====  Étudiants classiques =====\n");
        for (Etudiant e : allEtudiants) {
            if (!"apprentissage".equalsIgnoreCase(e.getType())) {
                List<String> choix = dao.getStudentChoixById(e.getId_etudiant());
                sb.append("• ").append(e.getNom()).append(" ").append(e.getPrenom()).append("\n");
                for (String ch : choix) {
                    sb.append("   ").append(ch).append("\n");
                }
                if (choix.isEmpty()) sb.append("   (Aucun choix soumis)\n");
                sb.append("\n");
            }
        }

        textArea.setText(sb.toString());

        // 🔽 Action du bouton pour voir les résultats finaux
        showFinalButton.addActionListener(e -> {
            Map<Integer, String> finals = dao.getFinalAttributions();
            StringBuilder result = new StringBuilder("===== Résultat final des attributions =====\n\n");

            for (Etudiant etu : allEtudiants) {
                result.append("• ").append(etu.getNom()).append(" ").append(etu.getPrenom());
                if (finals.containsKey(etu.getId_etudiant())) {
                    result.append(" → ").append(finals.get(etu.getId_etudiant())).append("\n");
                } else {
                    result.append(" →  Non affecté\n");
                }
            }

            JOptionPane.showMessageDialog(panel, new JScrollPane(new JTextArea(result.toString())), "Résultats finaux", JOptionPane.INFORMATION_MESSAGE);
        });

        return panel;
    }


    
    /**
     * Crée un panneau permettant de consulter la répartition des étudiants
     * selon leur dominante choisie.
     * @return JPanel de consultation des répartitions
     */
    private JPanel createOverviewPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel();
        JTextField directionField = new JTextField(15);
        JButton searchButton = new JButton("Interroger la direction spécifiée");
        JButton allButton = new JButton("Voir toutes les directions");

        topPanel.add(new JLabel("Orientation principale :"));
        topPanel.add(directionField);
        topPanel.add(searchButton);
        topPanel.add(allButton);

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        AttributionDAO dao = new AttributionDAO();

        allButton.addActionListener(e -> {
            resultArea.setText("");
            Map<String, List<String>> data = dao.getAllDirectionChoixDetails();
            StringBuilder sb = new StringBuilder();
            for (String dom : data.keySet()) {
                sb.append("【").append(dom).append("】 Nombre de candidats：").append(data.get(dom).size()).append("\n");
                for (String student : data.get(dom)) {
                    sb.append("  - ").append(student).append("\n");
                }
                sb.append("\n");
            }
            resultArea.setText(sb.toString());
        });

        searchButton.addActionListener(e -> {
            String direction = directionField.getText().trim();
            if (direction.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Veuillez entrer un nom de direction !");
                return;
            }

            List<String> list = dao.getStudentsForDirection(direction);
            if (list.isEmpty()) {
                resultArea.setText("Aucun dossier d'étudiant bénévole n'a été trouvé pour cette orientation.");
            } else {
                StringBuilder sb = new StringBuilder("【" + direction + "】 Nombre de candidats：" + list.size() + "\n");
                for (String s : list) {
                    sb.append("  - ").append(s).append("\n");
                }
                resultArea.setText(sb.toString());
            }
        });

        return panel;
    }

    /**
     * Crée un panneau permettant à l'administrateur de voir les choix effectués par un étudiant.
     * @return JPanel pour consulter les préférences des étudiants
     */
    private JPanel createStudentPreferencePanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel inputPanel = new JPanel();
        JTextField idField = new JTextField(10);
        JButton queryButton = new JButton("Requête");

        inputPanel.add(new JLabel("Veuillez saisir votre numéro d'étudiant："));
        inputPanel.add(idField);
        inputPanel.add(queryButton);

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        panel.add(inputPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        queryButton.addActionListener(e -> {
            String idText = idField.getText().trim();
            if (idText.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Veuillez saisir votre numéro d'étudiant！");
                return;
            }

            try {
                int id = Integer.parseInt(idText);
                AttributionDAO dao = new AttributionDAO();
                List<String> choix = dao.getStudentChoixById(id);

                if (choix.isEmpty()) {
                    resultArea.setText("Aucun dossier de bénévolat n'a été trouvé pour cet étudiant.");
                } else {
                    StringBuilder sb = new StringBuilder("Les étudiants bénévoles sont les suivants：\n\n");
                    for (String s : choix) {
                        sb.append(s).append("\n");
                    }
                    resultArea.setText(sb.toString());
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Veuillez saisir une pièce d'identité numérique valide");
            }
        });

        return panel;
    }

    /**
     * Crée un panneau pour gérer les informations des administrateurs :
     * ajout, suppression, modification de nom/prénom/mot de passe.
     * @return JPanel de gestion des administrateurs
     */
    private JPanel createAdminInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        String[] columnNames = {"ID", "nom", "prenom", "compte", "code"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        AdministrateurDAO adminDAO = new AdministrateurDAO();
        AuthentificationDAO authDAO = new AuthentificationDAO();

        // Remplir les données existantes
        for (Administrateur admin : adminDAO.getAllAdmins()) {
            Authentification auth = authDAO.getAuthById(admin.getId_ad_au());
            String compte = auth != null ? auth.getCompte() : "";
            String motdepasse = auth != null ? auth.getMotdepasse() : "";

            model.addRow(new Object[]{
                admin.getId_admini(),
                admin.getNom(),
                admin.getPrenom(),
                compte,
                motdepasse
            });
        }

        // Boutons d'action
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Ajouter");
        JButton deleteButton = new JButton("Supprimer");
        JButton updateNomButton = new JButton("Modifier nom");
        JButton updatePrenomButton = new JButton("Modifier prenom");
        JButton updatePasswordButton = new JButton("modifier code");
        JButton deconnecterButton = new JButton("deconnter");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateNomButton);
        buttonPanel.add(updatePrenomButton);
        buttonPanel.add(updatePasswordButton);
        buttonPanel.add(deconnecterButton);

        deconnecterButton.addActionListener(e -> {
            dispose();
            new AuthentificationGUI().setVisible(true);
        });

        addButton.addActionListener(e -> {
            String nom = JOptionPane.showInputDialog("Veuillez entrer votre nom：");
            String prenom = JOptionPane.showInputDialog("Veuillez entrer votre nom：");

            if (nom == null || prenom == null || nom.trim().isEmpty() || prenom.trim().isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Le nom ne peut pas être vide");
                return;
            }

            int newIdAu = authDAO.getMaxIdAu() + 1;
            String login = authDAO.generateUniqueAccount();
            String motdepasse = login;

            try {
                int authResult = authDAO.addAuthentification(newIdAu, login, motdepasse);
                if (authResult == -1) {
                    JOptionPane.showMessageDialog(panel, "Échec de l'ajout du compte !");
                    return;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, "Erreur : " + ex.getMessage());
                return;
            }

            int newIdAdmin = adminDAO.getMaxAdminId() + 1;
            Administrateur newAdmin = new Administrateur(newIdAdmin, nom, prenom, newIdAu);

            try {
                boolean adminResult = adminDAO.addAdministrateur(newAdmin);
                if (!adminResult) {
                    JOptionPane.showMessageDialog(panel, "Échec de l'ajout de l'administrateur !");
                    return;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, "Erreur : " + ex.getMessage());
                return;
            }

            model.addRow(new Object[]{newAdmin.getId_admini(), nom, prenom, login, motdepasse});
            JOptionPane.showMessageDialog(panel, "L'administrateur a été ajouté avec succès !");
        });

        deleteButton.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                int confirm = JOptionPane.showConfirmDialog(panel, "Êtes-vous sûr ?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int idAdmin = (int) model.getValueAt(selected, 0);
                    int idAu = adminDAO.getAdminById(idAdmin).getId_ad_au();
                    adminDAO.deleteAdministrateur(idAdmin);
                    authDAO.deleteAuthentificationById(idAu);
                    model.removeRow(selected);
                }
            }
        });

        updateNomButton.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                String newNom = JOptionPane.showInputDialog("Nouveau nom：");
                if (newNom != null && !newNom.trim().isEmpty()) {
                    int idAdmin = (int) model.getValueAt(selected, 0);
                    adminDAO.updateNom(idAdmin, newNom);
                    model.setValueAt(newNom, selected, 1);
                }
            }
        });

        updatePrenomButton.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                String newPrenom = JOptionPane.showInputDialog("Nouveau prenom：");
                if (newPrenom != null && !newPrenom.trim().isEmpty()) {
                    int idAdmin = (int) model.getValueAt(selected, 0);
                    adminDAO.updatePrenom(idAdmin, newPrenom);
                    model.setValueAt(newPrenom, selected, 2);
                }
            }
        });

        updatePasswordButton.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                String newPassword = JOptionPane.showInputDialog("Nouveau code：");
                if (newPassword != null && !newPassword.trim().isEmpty()) {
                    int idAdmin = (int) model.getValueAt(selected, 0);
                    int idAu = adminDAO.getAdminById(idAdmin).getId_ad_au();
                    authDAO.updateMotDePasse(new Authentification(idAu, "", newPassword));
                    model.setValueAt(newPassword, selected, 4);
                }
            }
        });

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    /**
     * Méthode principale pour démarrer l'interface graphique de l’administrateur.
     * @param args arguments de ligne de commande (non utilisés)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdministrateurGUI().setVisible(true));
    }
}
 