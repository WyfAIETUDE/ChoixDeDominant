package gui;

import dao.DominanteDAO;
import model.Dominante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Fenêtre indépendante affichant les informations des places classiques par dominante :
 * Dominante (nom), Places Totales (quota), Places Occupees (quotaApp)
 * 
 * @author YANG Zhen
 */
public class StatutPlacesClassiqueGUI extends JFrame {

    /**
     * Composant JTable permettant l'affichage tabulaire des données.
     */
    private JTable table;

    /**
     * Modèle de données de la JTable, utilisé pour gérer les lignes et colonnes dynamiquement.
     */
    private DefaultTableModel model;

    /**
     * DAO (Data Access Object) pour accéder aux objets de type Dominante depuis la base de données.
     */
    private DominanteDAO dao = new DominanteDAO();

    /**
     * Constructeur : initialise la fenêtre et son contenu.
     */
    public StatutPlacesClassiqueGUI() {
        setTitle("Statut des Places Classiques");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); 

        model = new DefaultTableModel(new Object[]{"Dominante", "Places Totales", "Places Occupees"}, 0);
        table = new JTable(model);

        loadData();

        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    /**
     * Charge les données depuis la table dominante.
     * Utilise quota comme Places Totales, et quotaApp comme Places Occupees.
     */
    private void loadData() {
        model.setRowCount(0);
        List<Dominante> list = dao.getAll();

        for (Dominante d : list) {
            String nom = d.getNomDomi();
            int placesTotales = d.getQuota();      
            int placesOccupees = d.getQuotaApp();  

            model.addRow(new Object[]{nom, placesTotales, placesOccupees});
        }
    }

    /**
     * Point d'entrée principal pour lancer la fenêtre seule.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StatutPlacesClassiqueGUI().setVisible(true);
        });
    }
}
