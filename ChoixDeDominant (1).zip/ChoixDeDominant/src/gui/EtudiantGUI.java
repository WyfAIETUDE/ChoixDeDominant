package gui;

import model.Etudiant;
import model.Dominante;
import dao.EtudiantDAO;
import dao.DominanteDAO;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.util.*;

/**
 * Interface graphique permettant à un étudiant de sélectionner ses dominantes
 * en fonction de sa filière (apprentissage ou classique).
 * Elle permet également la soumission, l'affichage et la gestion des choix.
 * 
 * @author  YANG Zhen / WU Yufan
 */
public class EtudiantGUI extends JFrame {

	/**
	 * L'étudiant actuellement connecté à l'application.
	 */
	private final Etudiant etudiant;

	/**
	 * Panneau contenant les zones de sélection des dominantes.
	 */
	private final JPanel choicePanel;

	/**
	 * Étiquette affichant le nombre de choix restants à l'étudiant.
	 */
	private final JLabel lblRemaining;

	/**
	 * DAO permettant de récupérer et manipuler les données des dominantes.
	 */
	private final DominanteDAO dominanteDAO = new DominanteDAO();

	/**
	 * Carte associant chaque JComboBox à la dominante sélectionnée,
	 * utilisée pour gérer les sélections uniques et la mise à jour des quotas.
	 */
	private final Map<JComboBox<Dominante>, Dominante> selectedMap = new HashMap<>();

	/**
	 * Liste des composants JComboBox représentant les différentes phases de choix.
	 */
	private final java.util.List<JComboBox<Dominante>> comboBoxes = new ArrayList<>();

	/**
	 * Indicateur permettant de prévenir les boucles d'événements lors de la modification des sélections.
	 */
	private boolean isAdjusting = false;


    /**
     * Constructeur principal qui initialise l'interface de choix des dominantes
     * pour un étudiant donné.
     *
     * @param etudiant L'étudiant pour lequel l'interface est générée.
     */
    public EtudiantGUI(Etudiant etudiant) {
        this.etudiant = etudiant;
        setTitle("Système - " + etudiant.getNom());
        setSize(540, 500);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        JPanel infoPanel = new JPanel();
        lblRemaining = new JLabel("Choix restants : " + getMaxChoices());
        infoPanel.add(lblRemaining);
        add(infoPanel, BorderLayout.NORTH);

        choicePanel = new JPanel();
        updateChoicePanel();
        add(new JScrollPane(choicePanel), BorderLayout.CENTER);

        JButton btnSubmit = new JButton("Soumettre");
        btnSubmit.addActionListener(e -> validateChoices());

        JButton btnView = new JButton("Voir les soumises");
        btnView.addActionListener(e -> showCurrentChoices());

        JButton informationDButton = new JButton("informationD");
        informationDButton.addActionListener(e -> {
            if (etudiant.getFiliere().equalsIgnoreCase("apprentissage")) {
                SwingUtilities.invokeLater(() -> {
                    StatutPlacesAppGUI appFrame = new StatutPlacesAppGUI();
                    appFrame.setVisible(true);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    StatutPlacesClassiqueGUI classiqueFrame = new StatutPlacesClassiqueGUI();
                    classiqueFrame.setVisible(true);
                });
            }
        });

        JButton deconnecterButton = new JButton("deconnecter");
        deconnecterButton.addActionListener(e -> {
            dispose();
            new AuthentificationGUI().setVisible(true);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnView);
        buttonPanel.add(informationDButton);
        buttonPanel.add(deconnecterButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    /**
     * Retourne le nombre maximum de choix autorisés selon la filière de l'étudiant.
     *
     * @return 2 pour apprentissage, 5 sinon.
     */
    private int getMaxChoices() {
        return etudiant.getFiliere().equalsIgnoreCase("apprentissage") ? 2 : 5;
    }

    /**
     * Met à jour le panneau contenant les zones de sélection des dominantes.
     */
    private void updateChoicePanel() {
        choicePanel.removeAll();
        comboBoxes.clear();
        choicePanel.setLayout(new GridLayout(0, 1));

        if (etudiant.getFiliere().equalsIgnoreCase("apprentissage")) {
            addPhasePanel("1er choix");
            addPhasePanel("2ème choix");
        } else {
            for (int i = 1; i <= 5; i++) {
                addPhasePanel("Choix n°" + i);
            }
        }

        choicePanel.revalidate();
        choicePanel.repaint();
    }

    /**
     * Ajoute un panneau de phase avec un JComboBox pour sélectionner une dominante.
     *
     * @param phaseName Le nom de la phase à afficher.
     */
    private void addPhasePanel(String phaseName) {
        JPanel phasePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        phasePanel.setBorder(BorderFactory.createTitledBorder(phaseName));

        List<Dominante> dominantes = dominanteDAO.getAll();
        JComboBox<Dominante> comboBox = new JComboBox<>();
        comboBox.addItem(null);

        for (Dominante d : dominantes) {
            comboBox.addItem(d);
        }

        comboBox.setPreferredSize(new Dimension(500, comboBox.getPreferredSize().height));
        comboBoxes.add(comboBox);

        comboBox.addActionListener(e -> {
            if (isAdjusting) return;
            isAdjusting = true;

            Dominante previous = selectedMap.get(comboBox);
            Dominante current = (Dominante) comboBox.getSelectedItem();

            if (previous != null) {
                etudiant.retirerChoix(previous);
                previous.decrementerPlace();
                selectedMap.remove(comboBox);
            }

            if (current != null) {
                for (JComboBox<Dominante> cb : comboBoxes) {
                    if (cb != comboBox && current.equals(cb.getSelectedItem())) {
                        JOptionPane.showMessageDialog(this, "Cette dominante a déjà été choisie dans une autre phase.");
                        comboBox.setSelectedItem(null);
                        isAdjusting = false;
                        return;
                    }
                }

                if (!current.peutAccepter()) {
                    JOptionPane.showMessageDialog(this, "Cette dominante est complète !");
                    comboBox.setSelectedItem(null);
                    isAdjusting = false;
                    return;
                }

                etudiant.ajouterChoix(current);
                if (etudiant.getFiliere().equalsIgnoreCase("apprentissage")) {
                    current.incrementerApprenti();
                } else {
                    current.incrementerClassique();
                }
                selectedMap.put(comboBox, current);
            }

            lblRemaining.setText("Choix restants : " + (getMaxChoices() - etudiant.getChoixDominantes().size()));
            isAdjusting = false;
        });

        phasePanel.add(comboBox);
        choicePanel.add(phasePanel);
    }

    /**
     * Valide les choix effectués par l’étudiant et les enregistre dans la base de données.
     */
    private void validateChoices() {
        if (etudiant.getChoixDominantes().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez choisir au moins une dominante !");
            return;
        }

        if (!etudiant.validerChoix()) {
            JOptionPane.showMessageDialog(this, "Date limite dépassée !");
            return;
        }

        EtudiantDAO dao = new EtudiantDAO();
        dao.deleteChoix(etudiant.getId_etudiant());
        dao.saveChoix(etudiant);
        JOptionPane.showMessageDialog(this, "Choix soumis avec succès !");
    }

    /**
     * Affiche les dominantes déjà soumises par l'étudiant, le cas échéant.
     */
    private void showCurrentChoices() {
        EtudiantDAO dao = new EtudiantDAO();
        List<String> choix = dao.getChoixDetailsByEtudiant(etudiant.getId_etudiant());

        if (choix.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucune dominante n'a encore été soumise.");
        } else {
            StringBuilder sb = new StringBuilder("Vos aspirations actuelles sont les suivantes :\n\n");
            for (String c : choix) {
                sb.append(c).append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString());
        }
    }
}
