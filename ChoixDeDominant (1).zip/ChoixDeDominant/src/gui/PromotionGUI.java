package gui;

import dao.PromotionDAO;
import dao.AuthentificationDAO;
import dao.EtudiantDAO; 
import dao.ChoixdedominanteDAOG;
import model.Promotion;
import model.Authentification;
import model.Etudiant;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * PromotionGUI est l'interface de gestion de scène
 * Fournit les fonctions d'ajout, de modification et de suppression de promotions et de leur statut d'étape
 * @author YANG Zhen
 * @version 2.00
 */
public class PromotionGUI extends JPanel {
	/**
	 * Tableau d'affichage principal des promotions.
	 */
	private JTable table;

	/**
	 * Modèle de données utilisé par la table pour gérer les lignes et colonnes.
	 */
	private DefaultTableModel model;

	/**
	 * DAO (Data Access Object) pour accéder aux données des promotions.
	 */
	private PromotionDAO dao = new PromotionDAO();

	/**
	 * DAO pour gérer les opérations liées aux étudiants.
	 */
	private EtudiantDAO etudiantDAO = new EtudiantDAO();


    public PromotionGUI() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{"ID", "Promotion", "etat"}, 0);
        table = new JTable(model);
        refreshTable();

        JPanel controlPanel = new JPanel();
        JButton btnUpdate = new JButton("modifier etat");
        JButton btnAdd = new JButton("ajoute Promotion");
        JButton btnDelete = new JButton("supprimer Promotion");
        JButton btnViewStudents = new JButton("voir les etudiants"); 

        btnUpdate.addActionListener(e -> updateEtat());
        btnAdd.addActionListener(e -> addPromotion());
        btnDelete.addActionListener(e -> deletePromotion());
        btnViewStudents.addActionListener(e -> showStudentsForPromotion()); 
        controlPanel.add(btnAdd);
        controlPanel.add(btnUpdate);
        controlPanel.add(btnDelete);
        controlPanel.add(btnViewStudents); 

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private void refreshTable() {
        model.setRowCount(0);
        List<Promotion> list = dao.getAll();
        for (Promotion p : list) {
            model.addRow(new Object[]{p.getId(), p.getNom(), p.getEtat()});
        }
    }

    private void updateEtat() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier!");
            return;
        }

        int id = (int) model.getValueAt(row, 0);
        String currentEtat = (String) model.getValueAt(row, 2);
        String[] etats = {"En préparation", "Apprentissage ouvert", "Apprentissage fermé", "Attribution de l’apprentissage terminée", "Classique ouvert", "Classique fermé", "Attribution du classique terminée", "Archivé"};

        String newEtat = (String) JOptionPane.showInputDialog(this, "Sélectionner une nouvelle état", "modifier etat",
                JOptionPane.PLAIN_MESSAGE, null, etats, currentEtat);

        if (newEtat != null && !newEtat.equals(currentEtat)) {
            dao.updateEtat(id, newEtat);
            refreshTable();
        }
    }

    private void addPromotion() {
        try {
            String nom = JOptionPane.showInputDialog(this, "Saisissez la promotion (par exemple 2025)：");
            if (nom == null || nom.trim().isEmpty()) return;

            String[] etats = {"En préparation", "Apprentissage ouvert", "Apprentissage fermé", "Attribution de l’apprentissage terminée", "Classique ouvert", "Classique fermé", "Attribution du classique terminée", "Archivé"};
            String etat = (String) JOptionPane.showInputDialog(this, "Choisir la phase initiale", "Créer une nouvelle etat",
                    JOptionPane.PLAIN_MESSAGE, null, etats, "En préparation");

            if (etat != null) {
                int nextId = dao.getNextId();
                dao.add(new Promotion(nextId, nom.trim(), etat));
                refreshTable();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Échec de l’ajout：" + e.getMessage());
        }
    }

    private void deletePromotion() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        int id = (int) model.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Confirmer la suppression de cette promotion？", "Confirmation de suppression", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dao.delete(id);
            refreshTable();
        }
    }

    /**
     * ✅ La fenêtre contextuelle affiche les informations sur les étudiants en promotion pour la session en cours et prend en charge l'ajout/la suppression d'étudiants.
     */
    private void showStudentsForPromotion() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez d'abord une promotion");
            return;
        }

        int idProm = (int) model.getValueAt(row, 0);
        List<Etudiant> etudiants = etudiantDAO.getEtudiantsByPromotion(idProm);

        String[] columns = {"ID", "nom", "prenom", "naissance","type", "Classement", "compte", "motdepasse"};
        DefaultTableModel studentModel = new DefaultTableModel(columns, 0);
        AuthentificationDAO authDAO = new AuthentificationDAO();
        for (Etudiant e : etudiants) {
            String compte = "";
            String motdepasse = "";

            Authentification auth = authDAO.getAuthById(e.getIdEtudAu());
            if (auth != null) {
                compte = auth.getCompte();
                motdepasse = auth.getMotdepasse();
            }
         // Formater la date de naissance au format de date français
            String formattedNaissance = e.getNaissance().format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE));

            studentModel.addRow(new Object[]{
                e.getId_etudiant(),
                e.getNom(),
                e.getPrenom(),
                formattedNaissance,
                e.getType(),
                e.getClassement(),
                compte,
                motdepasse
            });
        }


        JTable studentTable = new JTable(studentModel);
        JScrollPane scrollPane = new JScrollPane(studentTable);

     
        final JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Liste des étudiants", true);
        dialog.setLayout(new BorderLayout());
        
        

        JPanel btnPanel = new JPanel();
        JButton addBtn = new JButton("Ajouter étudiant");
        JButton deleteBtn = new JButton("Supprimer étudiant");
        JButton updateNomBtn = new JButton("Modifier nom");
        JButton updatePrenomBtn = new JButton("Modifier prénom");
        JButton updateNaissanceBtn = new JButton("Modifier naissance");
        JButton updateTypeBtn = new JButton("Modifier type");
        JButton updateClassementBtn = new JButton("Modifier classement");
        JButton updatePasswordBtn = new JButton("Modifier code");

   

        updateNomBtn.addActionListener(e -> {
            int row1 = studentTable.getSelectedRow();
            if (row1 == -1) return;

            int id = (int) studentModel.getValueAt(row1, 0);
            Etudiant etu = etudiantDAO.getEtudiantById(id);

            String newNom = JOptionPane.showInputDialog(dialog, "Saisir le nouveau nom de famille：", etu.getNom());
            if (newNom != null && !newNom.trim().isEmpty()) {
                etu.setNom(newNom.trim());
                etudiantDAO.updateEtudiant(etu);
                studentModel.setValueAt(newNom.trim(), row1, 1);
            }
        });
        
        updatePrenomBtn.addActionListener(e -> {
            int row2 = studentTable.getSelectedRow();
            if (row2 == -1) return;

            int id = (int) studentModel.getValueAt(row2, 0);
            Etudiant etu = etudiantDAO.getEtudiantById(id);

            String newPrenom = JOptionPane.showInputDialog(dialog, "Saisir le nouveau prénom：", etu.getPrenom());
            if (newPrenom != null && !newPrenom.trim().isEmpty()) {
                etu.setPrenom(newPrenom.trim());
                etudiantDAO.updateEtudiant(etu);
                studentModel.setValueAt(newPrenom.trim(), row2, 2);
            }
        });
        
        updateNaissanceBtn.addActionListener(e -> {
            int row6 = studentTable.getSelectedRow();
            if (row6 == -1) return;  

            int id = (int) studentModel.getValueAt(row6, 0);
            Etudiant etu = etudiantDAO.getEtudiantById(id); 

            if (etu == null) {
                JOptionPane.showMessageDialog(dialog, "Aucun enregistrement d'étudiant trouvé！");
                return;
            }

         // Si la date de naissance est vide, donnez une invite et renvoyez
            if (etu.getNaissance() == null) {
                JOptionPane.showMessageDialog(dialog, "La date de naissance de cet étudiant est vide, impossible de mettre à jour！");
                return;
            }

         // Affiche une zone de saisie permettant à l'utilisateur de saisir une nouvelle date de naissance
            String naissanceStr = JOptionPane.showInputDialog(dialog, "Saisir la nouvelle date de naissance (format : jj/mm/aaaa)：", etu.getNaissance().format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE)));
            if (naissanceStr != null && !naissanceStr.trim().isEmpty()) {
               
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE);
                    LocalDate newNaissance = LocalDate.parse(naissanceStr.trim(), formatter);

                 // Mettre à jour la date de naissance de l'étudiant
                    etu.setNaissance(newNaissance);

                    
                    int rowsAffected = etudiantDAO.updateEtudiant(etu);  
                    if (rowsAffected > 0) {
                      
                        studentModel.setValueAt(newNaissance.format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE)), row6, 3);
                        JOptionPane.showMessageDialog(dialog, "✅ La date de naissance a été mise à jour avec succès！");
                    } else {
                        JOptionPane.showMessageDialog(dialog, "❌ La mise à jour de la date de naissance a échoué！");
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Format de date invalide, veuillez utiliser le format jj/mm/aaaa！");
                }
            }
        });


        
        
        updateTypeBtn.addActionListener(e -> {
            int row3 = studentTable.getSelectedRow();
            if (row3 == -1) return;

            int id = (int) studentModel.getValueAt(row3, 0);
            Etudiant etu = etudiantDAO.getEtudiantById(id);

            String[] types = {"apprentissage", "classique"};
            String newType = (String) JOptionPane.showInputDialog(dialog, "Choisir une nouvelle identité：", "Modification de l'identité", JOptionPane.PLAIN_MESSAGE, null, types, etu.getType());
            if (newType != null) {
                etu.setType(newType);
                etudiantDAO.updateEtudiant(etu);
                studentModel.setValueAt(newType, row3, 3);
            }
        });

        updateClassementBtn.addActionListener(e -> {
            int row4 = studentTable.getSelectedRow();
            if (row4 == -1) return;

            int id = (int) studentModel.getValueAt(row4, 0);
            Etudiant etu = etudiantDAO.getEtudiantById(id);

            String classementStr = JOptionPane.showInputDialog(dialog, "Saisir le nouveau classement :", etu.getClassement());
            if (classementStr != null && !classementStr.trim().isEmpty()) {
                try {
                    int newClassement = Integer.parseInt(classementStr.trim());
                    etu.setClassement(newClassement);
                    etudiantDAO.updateEtudiant(etu);
                    studentModel.setValueAt(newClassement, row4, 4);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Veuillez saisir un numéro valide !");
                }
            }
        });

        updatePasswordBtn.addActionListener(e -> {
            int row5 = studentTable.getSelectedRow();
            if (row5 == -1) return;

            int id = (int) studentModel.getValueAt(row5, 0);
            Etudiant etu = etudiantDAO.getEtudiantById(id);

            Authentification auth = authDAO.getAuthById(etu.getIdEtudAu());
            if (auth == null) {
                JOptionPane.showMessageDialog(dialog, "Aucune information de compte trouvée pour cet étudiant !");
                return;
            }

            String newPass = JOptionPane.showInputDialog(dialog, "Saisir le nouveau mot de passe :", auth.getMotdepasse());
            if (newPass != null && !newPass.trim().isEmpty()) {
                auth.setMotdepasse(newPass.trim());
                authDAO.updateMotDePasse(auth);
                studentModel.setValueAt(newPass.trim(), row5, 6);
            }
        });

  
    

     //  Ajout d'une fonction étudiante (y compris la génération automatique de compte et de mot de passe)
        addBtn.addActionListener(e -> {
            try {
                String nom = JOptionPane.showInputDialog(dialog, "Veuillez saisir le nom de famille :");
                if (nom == null || nom.trim().isEmpty()) return;

                String prenom = JOptionPane.showInputDialog(dialog, "Veuillez saisir le prénom :");
                if (prenom == null || prenom.trim().isEmpty()) return;

                String naissanceStr = JOptionPane.showInputDialog(dialog, "Veuillez saisir la date de naissance (format : jj/mm/aaaa) :");
                if (naissanceStr == null || naissanceStr.trim().isEmpty()) return;

               
                LocalDate naissance;
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE);
                    naissance = LocalDate.parse(naissanceStr, formatter);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "❌ Format de date incorrect, veuillez utiliser le format jj/mm/aaaa (par exemple : 12/04/2025)");
                    return;
                }

                String[] types = {"apprentissage", "classique"};
                String type = (String) JOptionPane.showInputDialog(dialog, "Choisir le type", "Type", JOptionPane.PLAIN_MESSAGE, null, types, "apprentissage");
                if (type == null) return;

                String classementStr = JOptionPane.showInputDialog(dialog, "Veuillez saisir le classement (chiffre)");
                int classement = Integer.parseInt(classementStr);

                int newId = etudiantDAO.getNextId();

             // Construisez un objet Etudiant avec une date de naissance (vous devez prendre en charge LocalDate dans le constructeur)
                Etudiant newE = new Etudiant(newId, nom.trim(), prenom.trim(), naissance, idProm, classement, type, 0);

                boolean success = etudiantDAO.addEtudiantWithAuth(newE);

                if (success) {
                    studentModel.addRow(new Object[]{
                        newE.getId_etudiant(),
                        newE.getNom(),
                        newE.getPrenom(),
                        naissance.format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE)),
                        type,
                        classement
                     
                    });
                    JOptionPane.showMessageDialog(dialog, "✅ Étudiant ajouté avec succès, le compte et le mot de passe ont été générés !");
                } else {
                    JOptionPane.showMessageDialog(dialog, "❌ Échec de l'ajout, veuillez vérifier les saisies ou la connexion à la base de données");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Échec de l'ajout :" + ex.getMessage());
                ex.printStackTrace();
            }
        });



     // ✅ Fonction Supprimer l'étudiant (supprimer le compte et ses options en même temps)
        deleteBtn.addActionListener(e -> {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow == -1) return;

            int confirm = JOptionPane.showConfirmDialog(dialog, "Confirmer la suppression de l'étudiant sélectionné ?", "Confirmation de suppression", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    int idEtudiant = (int) studentModel.getValueAt(selectedRow, 0);
                    Etudiant etu = etudiantDAO.getEtudiantById(idEtudiant);

                  //Supprimez d'abord la sélection principale
                    ChoixdedominanteDAOG choix =new ChoixdedominanteDAOG();
                    choix.deleteChoixdedominanteByIdchoixetu(etu.getId_etudiant());
                    
                    //Supprimer à nouveau les étudiants
                    etudiantDAO.delete(idEtudiant);
                    
                 // Supprimer les informations du compte dans la table d'authentification
                    AuthentificationDAO authDAO1 = new AuthentificationDAO();
                    authDAO1.deleteAuthentificationById(etu.getIdEtudAu());


                    // Supprimer la ligne du tableau
                    studentModel.removeRow(selectedRow);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Échec de la suppression :" + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnPanel.add(addBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(updateNomBtn);
        btnPanel.add(updatePrenomBtn);
        btnPanel.add(updateNaissanceBtn);
        btnPanel.add(updateTypeBtn);
        btnPanel.add(updateClassementBtn);
        btnPanel.add(updatePasswordBtn);
        
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(btnPanel, BorderLayout.SOUTH);
        dialog.setSize(1100, 350);
        dialog.setLocationRelativeTo(this); // Affichage central
        dialog.setVisible(true); 
    }

}

