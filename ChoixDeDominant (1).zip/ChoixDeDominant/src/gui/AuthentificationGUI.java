package gui;

import dao.AuthentificationDAO;
import dao.EtudiantDAO;
import model.Etudiant;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * La classe {@code AuthentificationGUI} représente la fenêtre graphique
 * permettant à un utilisateur de se connecter au système.
 * Elle prend en charge la connexion pour les administrateurs ainsi que les étudiants
 * en filière classique ou en apprentissage.
 * Un fond personnalisé est affiché pour améliorer l'apparence visuelle.
 * 
 * @author YANG Zhen
 * @version 1.0
 */
public class AuthentificationGUI extends JFrame {
	
	/**
	 * Champ de saisie du nom de compte de l'utilisateur.
	 */
	private JTextField compteField;

	/**
	 * Champ de saisie du mot de passe de l'utilisateur.
	 */
	private JPasswordField motdepasseField;

	/**
	 * Bouton déclenchant l'action de connexion.
	 */
	private JButton loginButton;

	/**
	 * Étiquette affichant les messages d'erreur ou d'information liés à l'authentification.
	 */
	private JLabel statusLabel;


    /**
     * Constructeur qui initialise la fenêtre de connexion avec les composants nécessaires.
     */
    public AuthentificationGUI() {
        setTitle("Connexion");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centre la fenêtre à l'écran

        initComponents();
    }

    /**
     * Initialise et configure les composants de l'interface graphique :
     * champs de saisie, bouton de connexion, fond d'écran et interactions utilisateur.
     */
    private void initComponents() {
        // Chargement de l'image de fond depuis les ressources
        ImageIcon backgroundIcon = new ImageIcon(getClass().getResource("/resources/Esigelec.jpg"));
        Image backgroundImage = backgroundIcon.getImage();

        if (backgroundImage == null) {
            JOptionPane.showMessageDialog(this, "Image de fond introuvable !");
        }

        // Création d’un panneau avec un fond personnalisé
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        backgroundPanel.setLayout(new GridBagLayout());

        // Panneau du formulaire de connexion
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel compteLabel = new JLabel("Compte :");
        JLabel motdepasseLabel = new JLabel("Mot de passe :");

        // Couleur personnalisée pour les libellés
        Color gold = new Color(255, 215, 0);
        compteLabel.setForeground(gold);
        motdepasseLabel.setForeground(gold);

        compteField = new JTextField();
        motdepasseField = new JPasswordField();
        loginButton = new JButton("Connexion");
        statusLabel = new JLabel("");
        statusLabel.setForeground(Color.RED);

        formPanel.add(compteLabel);
        formPanel.add(compteField);
        formPanel.add(motdepasseLabel);
        formPanel.add(motdepasseField);
        formPanel.add(new JLabel());
        formPanel.add(loginButton);
        formPanel.add(statusLabel);

        // Positionnement du formulaire dans le panneau principal
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weighty = 0.3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTH;
        backgroundPanel.add(Box.createVerticalGlue(), gbc);

        gbc.gridy = 1;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        backgroundPanel.add(formPanel, gbc);

        setContentPane(backgroundPanel);

        // Gestion de l'action de connexion
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String compte = compteField.getText();
                String motdepasse = new String(motdepasseField.getPassword());

                AuthentificationDAO dao = new AuthentificationDAO();
                boolean valide = dao.verifierCompte(compte, motdepasse);

                if (valide) {
                    String role = dao.getRoleParCompte(compte);

                    switch (role) {
                        case "Administrateur":
                            new AdministrateurGUI().setVisible(true);
                            dispose();
                            break;
                        case "classique":
                        case "apprentissage":
                            EtudiantDAO etudiantDAO = new EtudiantDAO();
                            Etudiant etudiant = etudiantDAO.getEtudiantParCompte(compte);
                            if (etudiant != null) {
                                String etat = etudiantDAO.getEtatPromotionParCompte(compte);
                                if ((role.equals("classique") && "Classique ouvert".equalsIgnoreCase(etat)) ||
                                    (role.equals("apprentissage") && "Apprentissage ouvert".equalsIgnoreCase(etat))) {
                                    new EtudiantGUI(etudiant);
                                    dispose();
                                } else {
                                    JOptionPane.showMessageDialog(AuthentificationGUI.this,
                                            "La promotion est actuellement : " + etat,
                                            "Accès refusé", JOptionPane.WARNING_MESSAGE);
                                }
                            } else {
                                JOptionPane.showMessageDialog(AuthentificationGUI.this,
                                        "Étudiant introuvable pour ce compte !",
                                        "Erreur", JOptionPane.ERROR_MESSAGE);
                            }
                            break;
                        default:
                            JOptionPane.showMessageDialog(AuthentificationGUI.this,
                                    "Rôle inconnu ou non géré",
                                    "Erreur", JOptionPane.ERROR_MESSAGE);
                            break;
                    }

                } else {
                    statusLabel.setText("Connexion échouée. Vérifiez vos identifiants.");
                }
            }
        });
    }

    /**
     * Point d’entrée principal de l’application.
     * Lance la fenêtre de connexion à l’aide de l’EDT (Event Dispatch Thread).
     *
     * @param args arguments de la ligne de commande (non utilisés)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AuthentificationGUI().setVisible(true));
    }
}

    
   