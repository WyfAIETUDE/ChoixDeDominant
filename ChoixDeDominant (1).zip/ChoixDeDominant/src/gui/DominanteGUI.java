package gui;

import dao.DominanteDAO;
import model.Dominante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Interface graphique pour la gestion des dominantes.
 * Permet l'ajout, la modification et la suppression de dominantes.
 * Affiche un tableau avec les dominantes et fournit des boutons de contrôle.
 * 
 * @author YANG Zhen
 */
public class DominanteGUI extends JPanel {

	/**
	 * Table graphique affichant les données des dominantes.
	 */
    private JTable table;
    
    /**
     * Modèle de table utilisé pour gérer les données des dominantes dans l'interface.
     */
    private DefaultTableModel model;
    
    /**
     * Objet DAO utilisé pour interagir avec la base de données des dominantes.
     */
    private DominanteDAO dao = new DominanteDAO();

    /**
     * Constructeur : initialise les composants de l'interface graphique.
     */
    public DominanteGUI() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{"ID", "NomDominante", "Quota", "Sigle", "QuotaApp"}, 0);
        table = new JTable(model);
        refreshTable();

        JPanel controlPanel = new JPanel();
        JButton btnAdd = new JButton("ajouter une dominante");
        JButton btnUpdate = new JButton("modifier le quota");
        JButton btnDelete = new JButton("supprimer une dominante");
        JButton btnUpdate2 = new JButton("modifier le quotaApp");

        btnAdd.addActionListener(e -> addDomiante());
        btnUpdate.addActionListener(e -> updateQuota());
        btnDelete.addActionListener(e -> deleteDominante());
        btnUpdate2.addActionListener(e -> updateQuotaApp());

        controlPanel.add(btnAdd);
        controlPanel.add(btnUpdate);
        controlPanel.add(btnDelete);
        controlPanel.add(btnUpdate2);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    /**
     * Rafraîchit les données du tableau à partir de la base de données.
     */
    private void refreshTable() {
        model.setRowCount(0);
        List<Dominante> list = dao.getAll();
        for (Dominante d : list) {
            model.addRow(new Object[]{d.getId_dominante(), d.getNomDomi(), d.getQuota(), d.getSigle(), d.getQuotaApp()});
        }
    }

    /**
     * Ajoute une nouvelle dominante avec vérification de nom unique.
     */
    private void addDomiante() {
        try {
            String nom = JOptionPane.showInputDialog(this, "Saisir le nom de la dominante :");
            if (nom == null || nom.trim().isEmpty()) return;
            nom = nom.trim();

            // Vérification du nom unique
            List<Dominante> existing = dao.getAll();
            for (Dominante d : existing) {
                if (d.getNomDomi().equalsIgnoreCase(nom)) {
                    JOptionPane.showMessageDialog(this, "Ce dominante existe déjà !", "Erreur", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            String sigle = JOptionPane.showInputDialog(this, "Saisir le sigle de la dominante :");
            if (sigle == null || sigle.trim().isEmpty()) return;

            String quotaStr = JOptionPane.showInputDialog(this, "Saisir le quota (entier) :");
            if (quotaStr == null || quotaStr.trim().isEmpty()) return;

            String quotaStr2 = JOptionPane.showInputDialog(this, "Saisir le quotaApp (entier) :");
            if (quotaStr2 == null || quotaStr2.trim().isEmpty()) return;

            int quota;
            try {
                quota = Integer.parseInt(quotaStr.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Veuillez saisir un entier valide !", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int quotaApp;
            try {
                quotaApp = Integer.parseInt(quotaStr2.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Veuillez saisir un entier valide !", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int nextId = dao.getNextId();
            Dominante dominante = new Dominante(nextId, nom, quota, sigle.trim(), quotaApp);
            dao.add(dominante);

            refreshTable();
            JOptionPane.showMessageDialog(this, "Dominante ajoutée avec succès !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Échec de l'ajout : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Modifie le quota d'une dominante sélectionnée.
     */
    private void updateQuota() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier.");
            return;
        }

        int id = Integer.parseInt(table.getValueAt(row, 0).toString());
        Dominante dominante = dao.getById(id);
        if (dominante == null) {
            JOptionPane.showMessageDialog(this, "Aucune dominante trouvée.");
            return;
        }

        String newQuotaStr = JOptionPane.showInputDialog(this, "Saisir le nouveau quota :", dominante.getQuota());
        if (newQuotaStr == null || newQuotaStr.trim().isEmpty()) return;

        int newQuota;
        try {
            newQuota = Integer.parseInt(newQuotaStr.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir un entier valide !", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        dominante.setQuota(newQuota);
        if (dao.update(dominante)) {
            JOptionPane.showMessageDialog(this, "Modification réussie !");
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Échec de la modification !");
        }
    }

    /**
     * Modifie le quotaApp d'une dominante sélectionnée.
     */
    private void updateQuotaApp() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier.");
            return;
        }

        int id = Integer.parseInt(table.getValueAt(row, 0).toString());
        Dominante dominante = dao.getById(id);
        if (dominante == null) {
            JOptionPane.showMessageDialog(this, "Aucune dominante trouvée.");
            return;
        }

        String newQuotaStr = JOptionPane.showInputDialog(this, "Saisir le nouveau quotaApp :", dominante.getQuotaApp());
        if (newQuotaStr == null || newQuotaStr.trim().isEmpty()) return;

        int newQuota;
        try {
            newQuota = Integer.parseInt(newQuotaStr.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir un entier valide !", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        dominante.setQuotaApp(newQuota);
        if (dao.update(dominante)) {
            JOptionPane.showMessageDialog(this, "Modification réussie !");
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Échec de la modification !");
        }
    }

    /**
     * Supprime une dominante sélectionnée après confirmation.
     */
    private void deleteDominante() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        int id = (int) model.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Êtes-vous sûr de vouloir supprimer cette dominante ?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dao.delete(id);
            refreshTable();
        }
    }
}
