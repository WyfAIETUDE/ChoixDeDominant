package dao;

import java.sql.*;
import java.util.Random;
import model.Authentification;

/**
 * DAO (Data Access Object) pour la table {@code authentification}.
 * <p>
 * Cette classe permet d'effectuer diverses opérations sur la table d'authentification,
 * telles que la vérification de l'identité, l'obtention du rôle de l'utilisateur,
 * la génération de comptes uniques, ainsi que les opérations CRUD de base.
 * </p>
 * 
 * @author YANG Zhen
 */
public class AuthentificationDAO extends ConnectionDAO {

    public AuthentificationDAO() {
        super();
    }

    /**
     * Vérifie si un compte et un mot de passe donnés existent dans la base de données.
     *
     * @param compte     le nom du compte
     * @param motdepasse le mot de passe associé
     * @return {@code true} si le couple compte/mot de passe est valide, {@code false} sinon
     */
    public boolean verifierCompte(String compte, String motdepasse) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean existe = false;

        try {
            con = DriverManager.getConnection(URL, LOGIN, PASS);
            String sql = "SELECT * FROM authentification WHERE compte = ? AND motdepasse = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, compte);
            ps.setString(2, motdepasse);
            rs = ps.executeQuery();
            existe = rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignore) {}
            try { if (ps != null) ps.close(); } catch (Exception ignore) {}
            try { if (con != null) con.close(); } catch (Exception ignore) {}
        }

        return existe;
    }

    /**
     * Récupère le rôle de l'utilisateur en fonction de son compte.
     *
     * @param compte le nom du compte
     * @return le rôle de l'utilisateur (ex: "Administrateur", "Classique", "Apprenti"), ou {@code null} si non trouvé
     */
    public String getRoleParCompte(String compte) {
        String role = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection(URL, LOGIN, PASS);

            String sqlId = "SELECT id_au FROM authentification WHERE compte = ?";
            ps = con.prepareStatement(sqlId);
            ps.setString(1, compte);
            rs = ps.executeQuery();

            if (rs.next()) {
                int id_au = rs.getInt("id_au");
                rs.close(); ps.close();

                String sqlAdmin = "SELECT * FROM administrateur WHERE id_ad_au = ?";
                ps = con.prepareStatement(sqlAdmin);
                ps.setInt(1, id_au);
                rs = ps.executeQuery();

                if (rs.next()) {
                    role = "Administrateur";
                } else {
                    rs.close(); ps.close();

                    String sqlEtud = "SELECT type FROM etudiant WHERE id_etud_au = ?";
                    ps = con.prepareStatement(sqlEtud);
                    ps.setInt(1, id_au);
                    rs = ps.executeQuery();

                    if (rs.next()) {
                        role = rs.getString("type");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignore) {}
            try { if (ps != null) ps.close(); } catch (Exception ignore) {}
            try { if (con != null) con.close(); } catch (Exception ignore) {}
        }

        return role;
    }

    /**
     * Récupère l'identifiant maximal existant dans la table {@code authentification}.
     *
     * @return la plus grande valeur de {@code id_au}, ou 0 si la table est vide
     */
    public int getMaxIdAu() {
        String sql = "SELECT NVL(MAX(id_au), 0) FROM authentification";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Insère un nouvel enregistrement dans la table {@code authentification}.
     *
     * @param idAu     l'identifiant unique du compte
     * @param login    le nom d'utilisateur
     * @param password le mot de passe
     * @return l'identifiant {@code idAu} si l'insertion a réussi, {@code -1} sinon
     */
    public int addAuthentification(int idAu, String login, String password) {
        String sql = "INSERT INTO authentification (id_au, compte, motdepasse) VALUES (?, ?, ?)";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAu);
            ps.setString(2, login);
            ps.setString(3, password);
            int rows = ps.executeUpdate();

            return rows > 0 ? idAu : -1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Génère un identifiant de compte aléatoire de 8 chiffres qui n'existe pas encore dans la base.
     *
     * @return une chaîne unique de 8 chiffres
     */
    public String generateUniqueAccount() {
        String chars = "0123456789";
        Random rand = new Random();
        String account;

        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                sb.append(chars.charAt(rand.nextInt(chars.length())));
            }
            account = sb.toString();
        } while (accountExists(account));

        return account;
    }

    /**
     * Vérifie si un compte existe déjà dans la base de données.
     *
     * @param login le nom d'utilisateur à vérifier
     * @return {@code true} si le compte existe, {@code false} sinon
     */
    public boolean accountExists(String login) {
        String sql = "SELECT COUNT(*) FROM authentification WHERE compte = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, login);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Récupère un objet {@code Authentification} à partir de son identifiant.
     *
     * @param idAu l'identifiant du compte
     * @return un objet {@code Authentification}, ou {@code null} si introuvable
     */
    public Authentification getAuthById(int idAu) {
        String sql = "SELECT compte, motdepasse FROM authentification WHERE id_au = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAu);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Authentification(idAu, rs.getString("compte"), rs.getString("motdepasse"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Supprime un compte de la base à partir de son identifiant.
     *
     * @param idAu l'identifiant du compte à supprimer
     * @return {@code true} si la suppression a été effectuée, {@code false} sinon
     */
    public boolean deleteAuthentificationById(int idAu) {
        String sql = "DELETE FROM authentification WHERE id_au = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAu);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Met à jour le mot de passe d'un compte.
     *
     * @param auth un objet {@code Authentification} contenant le nouvel identifiant et mot de passe
     * @throws RuntimeException en cas d'erreur lors de la mise à jour
     */
    public void updateMotDePasse(Authentification auth) {
        String sql = "UPDATE authentification SET motdepasse = ? WHERE id_au = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, auth.getMotdepasse());
            stmt.setInt(2, auth.getId_au());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Échec de la mise à jour du mot de passe : " + e.getMessage());
        }
    }
}

	

