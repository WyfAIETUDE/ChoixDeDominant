package dao;

import model.Etudiant;
import model.Dominante;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) pour manipuler les données de la table "etudiant".
 * Fournit des méthodes CRUD ainsi que des opérations spécifiques liées à l'étudiant :
 * récupération par promotion, enregistrement des choix de dominante, etc.
 * Hérite de ConnectionDAO pour bénéficier de la connexion à la base de données.
 * 
 * @author WU Yufan
 * @version 1.0
 */
public class EtudiantDAO extends ConnectionDAO {

    /**
     * Récupère tous les étudiants appartenant à une promotion donnée,
     * triés par leur classement.
     * 
     * @param idPromotion l'identifiant de la promotion
     * @return liste des étudiants
     */
    public List<Etudiant> getEtudiantsByPromotion(int idPromotion) {
        List<Etudiant> list = new ArrayList<>();
        String sql = "SELECT * FROM etudiant WHERE id_promotion = ? ORDER BY classement ASC";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idPromotion);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Date sqlDate = rs.getDate("naissance");
                    LocalDate naissance = (sqlDate != null) ? sqlDate.toLocalDate() : null;

                    list.add(new Etudiant(
                            rs.getInt("id_etudiant"),
                            rs.getString("nom"),
                            rs.getString("prenom"),
                            naissance,
                            rs.getInt("id_promotion"),
                            rs.getInt("classement"),
                            rs.getString("type"),
                            rs.getInt("id_etud_au")
                    ));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Récupère le prochain ID disponible pour un nouvel étudiant.
     * 
     * @return le prochain identifiant
     */
    public int getNextId() {
        String sql = "SELECT MAX(id_etudiant) FROM etudiant";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1) + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    /**
     * Ajoute un nouvel étudiant dans la base de données.
     * 
     * @param e l'étudiant à ajouter
     * @return 1 si l’insertion a réussi, 0 sinon
     */
    public int addEtudiant(Etudiant e) {
        String sql = "INSERT INTO etudiant (id_etudiant, nom, prenom, naissance, id_promotion, classement, type, id_etud_au) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            java.sql.Date naissanceDate = java.sql.Date.valueOf(e.getNaissance());

            ps.setInt(1, e.getId_etudiant());
            ps.setString(2, e.getNom());
            ps.setString(3, e.getPrenom());
            ps.setDate(4, naissanceDate);
            ps.setInt(5, e.getIdPromotion());
            ps.setInt(6, e.getClassement());
            ps.setString(7, e.getType());
            ps.setInt(8, e.getIdEtudAu());

            return ps.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    /**
     * Récupère un étudiant à partir de son compte utilisateur.
     * 
     * @param compte identifiant de connexion (compte)
     * @return l’étudiant correspondant ou null si non trouvé
     */
    public Etudiant getEtudiantParCompte(String compte) {
        String sql = "SELECT e.* FROM etudiant e " +
                     "JOIN authentification a ON e.id_etud_au = a.id_au " +
                     "WHERE a.compte = ?";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, compte);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                java.sql.Date naissanceSqlDate = rs.getDate("naissance");
                LocalDate naissance = (naissanceSqlDate != null) ? naissanceSqlDate.toLocalDate() : null;

                return new Etudiant(
                        rs.getInt("id_etudiant"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        naissance,
                        rs.getInt("id_promotion"),
                        rs.getInt("classement"),
                        rs.getString("type"),
                        rs.getInt("id_etud_au")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Supprime un étudiant de la base de données.
     * 
     * @param id l’identifiant de l’étudiant
     * @return 1 si la suppression a réussi, 0 sinon
     */
    public int delete(int id) {
        String sql = "DELETE FROM etudiant WHERE id_etudiant = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Met à jour les informations d’un étudiant.
     * 
     * @param e l’étudiant mis à jour
     * @return 1 si la mise à jour a réussi, 0 sinon
     */
    public int updateEtudiant(Etudiant e) {
        String sql = "UPDATE etudiant SET nom = ?, prenom = ?, naissance = ?, id_promotion = ?, classement = ?, type = ?, id_etud_au = ? WHERE id_etudiant = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            java.sql.Date naissanceDate = java.sql.Date.valueOf(e.getNaissance());

            ps.setString(1, e.getNom());
            ps.setString(2, e.getPrenom());
            ps.setDate(3, naissanceDate);
            ps.setInt(4, e.getIdPromotion());
            ps.setInt(5, e.getClassement());
            ps.setString(6, e.getType());
            ps.setInt(7, e.getIdEtudAu());
            ps.setInt(8, e.getId_etudiant());

            return ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    /**
     * Ajoute un étudiant en créant également un compte utilisateur associé.
     * 
     * @param e l’étudiant à ajouter
     * @return true si l’opération est un succès, false sinon
     */
    public boolean addEtudiantWithAuth(Etudiant e) {
        try {
            AuthentificationDAO authDAO = new AuthentificationDAO();

            String login = authDAO.generateUniqueAccount();
            String password = login;

            int newIdAu = authDAO.getMaxIdAu() + 1;
            int insertedId = authDAO.addAuthentification(newIdAu, login, password);
            if (insertedId == -1) {
                System.err.println("❌ Échec de l'insertion du compte");
                return false;
            }

            e.setIdEtudAu(insertedId);
            int result = addEtudiant(e);
            return result > 0;

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Enregistre les choix de dominante de l’étudiant dans la table CHOIXDOMINANTE.
     * 
     * @param etudiant l’étudiant concerné
     */
    public void saveChoix(Etudiant etudiant) {
        String sql = "INSERT INTO CHOIXDOMINANTE (ID_CHOIX, ID_CHOIXDOM_DOM, ORDRE_CLASSEMENT, ID_CHOIX_ETU) VALUES (?, ?, ?, ?)";
        List<Dominante> choix = etudiant.getChoixDominantes();

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            int nextId = getMaxIdChoix();
            int ordre = 1;

            for (Dominante dom : choix) {
                ps.setInt(1, ++nextId);
                ps.setInt(2, dom.getId_dominante());
                ps.setInt(3, ordre++);
                ps.setInt(4, etudiant.getId_etudiant());
                ps.addBatch();
            }

            ps.executeBatch();
            System.out.println("✅ etudiant " + etudiant.getNom() + " Le choix de spécialité a été enregistré avec succès");

        } catch (SQLException e) {
            System.err.println("❌ Échec de l'enregistrement du choix de spécialité de l'étudiant !");
            e.printStackTrace();
        }
    }

    /**
     * Récupère le plus grand identifiant (ID_CHOIX) dans la table CHOIXDOMINANTE.
     * 
     * @return le plus grand ID ou 0 si vide
     */
    public int getMaxIdChoix() {
        String sql = "SELECT NVL(MAX(ID_CHOIX), 0) FROM CHOIXDOMINANTE";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Récupère un étudiant par son identifiant.
     * 
     * @param idEtudiant identifiant de l'étudiant
     * @return l’étudiant ou null si non trouvé
     */
    public Etudiant getEtudiantById(int idEtudiant) {
        String sql = "SELECT * FROM etudiant WHERE id_etudiant = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEtudiant);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                java.sql.Date naissanceSqlDate = rs.getDate("naissance");
                LocalDate naissance = (naissanceSqlDate != null) ? naissanceSqlDate.toLocalDate() : null;

                return new Etudiant(
                        rs.getInt("id_etudiant"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        naissance,
                        rs.getInt("id_promotion"),
                        rs.getInt("classement"),
                        rs.getString("type"),
                        rs.getInt("id_etud_au")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Récupère tous les étudiants triés par classement.
     * 
     * @return liste des étudiants
     */
    public List<Etudiant> getAllEtudiants() {
        List<Etudiant> list = new ArrayList<>();
        String sql = "SELECT * FROM etudiant ORDER BY classement ASC";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                java.sql.Date naissanceSql = rs.getDate("naissance");
                LocalDate naissance = (naissanceSql != null) ? naissanceSql.toLocalDate() : null;

                Etudiant e = new Etudiant(
                        rs.getInt("id_etudiant"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        naissance,
                        rs.getInt("id_promotion"),
                        rs.getInt("classement"),
                        rs.getString("type"),
                        rs.getInt("id_etud_au")
                );
                list.add(e);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Supprime les choix de dominante d’un étudiant.
     * 
     * @param idEtudiant identifiant de l'étudiant
     */
    public void deleteChoix(int idEtudiant) {
        String sql = "DELETE FROM CHOIXDOMINANTE WHERE ID_CHOIX_ETU = ? AND ORDRE_CLASSEMENT > 0";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEtudiant);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Récupère les détails des choix de dominante d’un étudiant.
     * 
     * @param idEtudiant identifiant de l'étudiant
     * @return liste de chaînes de caractères représentant les choix classés
     */
    public List<String> getChoixDetailsByEtudiant(int idEtudiant) {
        List<String> list = new ArrayList<>();
        String sql =
            "SELECT d.nomdomi, c.ORDRE_CLASSEMENT " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE c.ID_CHOIX_ETU = ? AND c.ORDRE_CLASSEMENT > 0 " +
            "ORDER BY c.ORDRE_CLASSEMENT";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEtudiant);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int ordre = rs.getInt("ORDRE_CLASSEMENT");
                String nom = rs.getString("nomdomi");
                list.add("le" + ordre + " choix：" + nom);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    
    /**
     * Récupère les choix de dominante (objets Dominante) faits par un étudiant.
     *
     * @param idEtudiant identifiant de l’étudiant
     * @return liste ordonnée des objets Dominante
     */
    public List<Dominante> getChoixDominantesPourEtudiant(int idEtudiant) {
        List<Dominante> list = new ArrayList<>();
        String sql =
            "SELECT d.ID_DOMINANTE, d.NOMDOMI, d.QUOTA, d.SIGLE, d.QUOTAAPP " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE c.ID_CHOIX_ETU = ? AND c.ORDRE_CLASSEMENT > 0 " +
            "ORDER BY c.ORDRE_CLASSEMENT ASC";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEtudiant);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Dominante d = new Dominante(
                    rs.getInt("ID_DOMINANTE"),
                    rs.getString("NOMDOMI"),
                    rs.getInt("QUOTA"),
                    rs.getString("SIGLE"),
                    rs.getInt("QUOTAAPP")
                );
                list.add(d);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    
    /**
     * Récupère l'état de la promotion d'un étudiant via son compte.
     *
     * @param compte login de l'étudiant
     * @return l'état de la promotion ("Classique ouvert", etc.) ou null si non trouvé
     */
    public String getEtatPromotionParCompte(String compte) {
        String sql = "SELECT etat FROM etudiant  " +
                     "JOIN promotion  ON etudiant.id_promotion = promotion.id_prom " +
                     "JOIN authentification  ON etudiant.id_etud_au = authentification.id_au " +
                     "WHERE authentification.compte = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, compte);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("etat");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

