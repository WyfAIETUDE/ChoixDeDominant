package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * DAO (Data Access Object) pour la gestion des choix de dominante.
 * <p>
 * Cette classe permet d'effectuer des opérations sur la table {@code choixdominante},
 * en particulier la suppression d'un choix de dominante lié à un étudiant.
 * </p>
 * 
 * @author    YANG Zhen
 */
public class ChoixdedominanteDAOG extends ConnectionDAO {

    /**
     * Supprime un choix de dominante en fonction de l'identifiant du choix de l'étudiant.
     *
     * @param idchoix l'identifiant du choix de dominante de l'étudiant
     * @return le nombre de lignes supprimées (généralement 1 si succès, 0 sinon)
     */
    public int deleteChoixdedominanteByIdchoixetu(int idchoix) {
        String sql = "DELETE FROM choixdominante WHERE id_choix_etu = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idchoix);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
