package dao;

/**
 * Classe de gestion de la connexion à la base de données Oracle.
 * 
 * Cette classe initialise le pilote JDBC pour Oracle et définit
 * les paramètres de connexion à la base de données (URL, identifiant, mot de passe).
 * Exemple d'utilisation :
 * Remarque : cette classe ne crée pas directement la connexion, elle charge uniquement le pilote.
 * La création d'une instance de {@code java.sql.Connection} devra être gérée ailleurs (ex : via DriverManager).
 *
 * @author yangzhen
 * @version 1.0
 */
public class ConnectionDAO {

    /**
     * URL de connexion à la base de données Oracle.
     * 
     * Utiliser cette URL si vous êtes sur une machine personnelle :
     * {@code jdbc:oracle:thin:@oracle.esigelec.fr:1521:orcl}
     * 
     * 
     * 
     * Pour une machine de l'école, décommentez la ligne suivante :
     * {@code jdbc:oracle:thin:@//srvoracledb.intranet.int:1521/orcl.intranet.int}
     *
     */
    final static String URL = "jdbc:oracle:thin:@oracle.esigelec.fr:1521:orcl";

    /**
     * Nom d'utilisateur (identifiant) pour se connecter à la base Oracle.
     * Remplacez par votre propre identifiant, par exemple {@code C##BDD1_1}.
     */
    final static String LOGIN = "C##BDD8_14";

    /**
     * Mot de passe associé à l'identifiant Oracle.
     * Remplacez par votre mot de passe réel, par exemple {@code BDD11}.
     */
    final static String PASS = "BDD814";

    /**
     * Constructeur de la classe {@code ConnectionDAO}.
     
     * Ce constructeur charge le pilote JDBC d'Oracle, nécessaire pour établir des connexions avec la base de données.
     * Si le chargement échoue, un message d'erreur est affiché dans la sortie d'erreur standard.
     * Assurez-vous que le fichier {@code ojdbc8.jar} ou équivalent est bien ajouté au classpath du projet.
    
     */
    public ConnectionDAO() {
        // Chargement du pilote JDBC Oracle
        try {
            Class.forName("oracle.jdbc.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.err.println("Impossible de charger le pilote de BDD, ne pas oublier d'importer le fichier .jar dans le projet");
        }
    }

}
