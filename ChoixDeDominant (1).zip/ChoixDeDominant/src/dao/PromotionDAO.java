package dao;

import java.sql.*;
import java.util.ArrayList;
import model.Promotion;

/**
 *La classe PromotionDAO est la classe d'opérations sur la base de données pour la table promotion (année de promotion).
 * Fournir des méthodes pour obtenir, ajouter, supprimer et modifier les données de promotion.
 * @author  YANG Zhen 
 * @version 1.0
 */
public class PromotionDAO extends ConnectionDAO {

    /**
     * @return Promotion list
     */
    public ArrayList<Promotion> getAll() {
        ArrayList<Promotion> list = new ArrayList<>();
        String sql = "SELECT * FROM promotion ORDER BY id_prom";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

           
            while (rs.next()) {
                list.add(new Promotion(
                    rs.getInt("id_prom"),        
                    rs.getString("nompromotion"), 
                    rs.getString("etat")        
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Mettre à jour l'état de phase de la promotion spécifiée.
     * @param id promotion  ID
     * @param newEtat 
     * @return Mettre à jour le nombre de lignes affectées
     */
    public int updateEtat(int id, String newEtat) {
        String sql = "UPDATE promotion SET etat = ? WHERE id_prom = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newEtat); 
            ps.setInt(2, id);         
            return ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; 
    }

    /**
     * Ajouter une nouvelle promotion à la base de données.
     * @param promo Promotion 
     * @return Nombre d'enregistrements insérés avec succès (devrait être 1).
     */
    public int add(Promotion promo) {
        String sql = "INSERT INTO promotion (id_prom, nompromotion, etat) VALUES (?, ?, ?)";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, promo.getId());          
            ps.setString(2, promo.getNom());       
            ps.setString(3, promo.getEtat());      
            return ps.executeUpdate();             

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; 
    }

    /**
     * Obtenir le prochain ID disponible (ID maximum + 1).
     * @return Nouvelle valeur de l'ID.
     */
    public int getNextId() {
        String sql = "SELECT MAX(id_prom) FROM promotion";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1) + 1; 
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1; 
    }

    /**
     * Supprimer la promotion spécifiée.
     * @param id promotion 
     * @return Nombre d'enregistrements supprimés avec succès.
     */
    public int delete(int id) {
        String sql = "DELETE FROM promotion WHERE id_prom = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id); 
            return ps.executeUpdate(); 

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; 
    }
}



