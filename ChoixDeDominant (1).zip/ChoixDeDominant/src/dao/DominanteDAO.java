package dao;

import model.Dominante;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * DAO (Data Access Object) pour effectuer les opérations sur la table {@code dominante}.
 * Fournit les opérations de base CRUD : lecture de tous les enregistrements, 
 * recherche par ID, ajout, mise à jour et suppression.
 * Cette classe hérite de {@code ConnectionDAO} pour réutiliser les méthodes de connexion à la base.
 *
 * Structure de la table supposée :
 * - id_dominante : int (clé primaire)
 * - nomdomi : varchar
 * - quota : int
 * - sigle : varchar
 * 
 * @author YANG Zhen / WU yufan
 * @version 1.0
 */
public class DominanteDAO extends ConnectionDAO {

    /**
     * Récupère toutes les dominantes présentes dans la base de données.
     * 
     * @return une liste contenant tous les objets {@code Dominante}
     */
    public List<Dominante> getAll() {
        List<Dominante> list = new ArrayList<>();
        String sql = "SELECT * FROM dominante";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Dominante(
                        rs.getInt("id_dominante"),
                        rs.getString("nomdomi"),
                        rs.getInt("quota"),
                        rs.getString("sigle"),
                        rs.getInt("quotaapp")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Recherche une dominante par son identifiant.
     * 
     * @param id l'identifiant de la dominante
     * @return l'objet {@code Dominante} correspondant, ou {@code null} si non trouvé
     */
    public Dominante getById(int id) {
        String sql = "SELECT * FROM dominante WHERE id_dominante = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Dominante(
                        rs.getInt("id_dominante"),
                        rs.getString("nomdomi"),
                        rs.getInt("quota"),
                        rs.getString("sigle"),
                        rs.getInt("quotaapp")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Ajoute une nouvelle dominante à la base de données.
     * 
     * @param dominante l'objet {@code Dominante} à ajouter
     * @return {@code true} si l'ajout a réussi, {@code false} sinon
     */
    public boolean add(Dominante dominante) {
        String sql = "INSERT INTO dominante (id_dominante, nomdomi, quota, sigle,quotaapp) VALUES (?, ?, ?, ?,?)";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, dominante.getId_dominante());
            ps.setString(2, dominante.getNomDomi());
            ps.setInt(3, dominante.getQuota());
            ps.setString(4, dominante.getSigle());
            ps.setInt(5, dominante.getQuotaApp());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Met à jour une dominante existante dans la base de données.
     * 
     * @param dominante l'objet {@code Dominante} contenant les nouvelles valeurs
     * @return {@code true} si la mise à jour a réussi, {@code false} sinon
     */
    public boolean update(Dominante dominante) {
        String sql = "UPDATE dominante SET nomdomi = ?, quota = ?, sigle = ?,quotaapp = ? WHERE id_dominante = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, dominante.getNomDomi());
            ps.setInt(2, dominante.getQuota());
            ps.setString(3, dominante.getSigle());
            ps.setInt(4, dominante.getQuotaApp());
            ps.setInt(5, dominante.getId_dominante());
            

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Supprime une dominante de la base selon son identifiant.
     * 
     * @param id l'identifiant de la dominante à supprimer
     * @return {@code true} si la suppression a réussi, {@code false} sinon
     */
    public boolean delete(int id) {
        String sql = "DELETE FROM dominante WHERE id_dominante = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Récupère le prochain identifiant disponible pour une dominante.
     * 
     * @return le prochain ID (max + 1), ou 1 si la table est vide
     */
    public int getNextId() {
        String sql = "SELECT MAX(id_dominante) FROM dominante";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1) + 1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1; // Commencer à 1 si la table est vide
    }

    /**
     * Récupère la capacité (quota) disponible pour chaque dominante.
     * 
     * @return une map où la clé est le nom de la dominante et la valeur est sa capacité (quota)
     */
    public Map<String, Integer> getDominanteCapacities() {
        Map<String, Integer> capacities = new HashMap<>();
        String sql = "SELECT nomdomi, quota FROM dominante";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String nom = rs.getString("nomdomi");
                int quota = rs.getInt("quota");
                capacities.put(nom, quota);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return capacities;
    }
    
    /**
     * Récupère le quota total par dominante.
     */
    public Map<String, Integer> getQuotaTotal() {
        Map<String, Integer> quotas = new HashMap<>();
        String sql = "SELECT nomdomi, quota FROM dominante";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                quotas.put(rs.getString("nomdomi"), rs.getInt("quota"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return quotas;
    }
    
    

    /**
     * Récupère le quota réservé aux apprentis.
     */
    public Map<String, Integer> getQuotaApprenti() {
        Map<String, Integer> quotas = new HashMap<>();
        String sql = "SELECT nomdomi, quotaapp FROM dominante";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                quotas.put(rs.getString("nomdomi"), rs.getInt("quotaapp"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return quotas;
    }

}
