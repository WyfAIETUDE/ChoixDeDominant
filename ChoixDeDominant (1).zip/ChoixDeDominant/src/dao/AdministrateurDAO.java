package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Administrateur;

/**
 * DAO (Data Access Object) pour la table "administrateur".
 * Cette classe fournit les méthodes nécessaires pour gérer les opérations
 * CRUD (Create, Read, Update, Delete) sur les administrateurs dans la base de données.
 * 
 * @author yang
 * @version 2.0
 */
public class AdministrateurDAO extends ConnectionDAO {

    /**
     * Constructeur par défaut. Initialise la connexion à la base de données.
     */
    public AdministrateurDAO() {
        super();
    }

    /**
     * Ajoute un administrateur dans la base de données.
     *
     * @param admin L'objet Administrateur à ajouter.
     * @return true si l'insertion a réussi, false sinon.
     */
    public boolean addAdministrateur(Administrateur admin) {
        String sql = "INSERT INTO administrateur (id_admini, nom, prenom, id_ad_au) VALUES (?, ?, ?, ?)";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, admin.getId_admini());
            ps.setString(2, admin.getNom());
            ps.setString(3, admin.getPrenom());
            ps.setInt(4, admin.getId_ad_au());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Supprime un administrateur de la base à partir de son ID.
     *
     * @param idAdmin L'identifiant de l'administrateur à supprimer.
     * @return true si la suppression a réussi, false sinon.
     */
    public boolean deleteAdministrateur(int idAdmin) {
        String sql = "DELETE FROM administrateur WHERE id_admini = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAdmin);
            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Récupère l'identifiant maximal existant dans la table administrateur.
     *
     * @return L'ID maximum existant ou 1 si aucun ID n'est présent.
     */
    public int getMaxAdminId() {
        String sql = "SELECT MAX(id_admini) FROM administrateur";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                int maxId = rs.getInt(1);
                return maxId > 0 ? maxId : 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    /**
     * Récupère un administrateur à partir de son ID.
     *
     * @param idAdmin L'identifiant de l'administrateur.
     * @return Un objet Administrateur correspondant, ou null si introuvable.
     */
    public Administrateur getAdminById(int idAdmin) {
        String sql = "SELECT * FROM administrateur WHERE id_admini = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAdmin);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int id_admini = rs.getInt("id_admini");
                String nom = rs.getString("nom");
                String prenom = rs.getString("prenom");
                int id_ad_au = rs.getInt("id_ad_au");

                return new Administrateur(id_admini, nom, prenom, id_ad_au);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Met à jour le nom d'un administrateur.
     *
     * @param id L'identifiant de l'administrateur.
     * @param newNom Le nouveau nom à attribuer.
     */
    public void updateNom(int id, String newNom) {
        String sql = "UPDATE administrateur SET nom = ? WHERE id_admini = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newNom);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Met à jour le prénom d'un administrateur.
     *
     * @param id L'identifiant de l'administrateur.
     * @param newPrenom Le nouveau prénom à attribuer.
     */
    public void updatePrenom(int id, String newPrenom) {
        String sql = "UPDATE administrateur SET prenom = ? WHERE id_admini = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newPrenom);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Récupère tous les administrateurs présents dans la base de données.
     *
     * @return Une liste d'objets Administrateur.
     */
    public ArrayList<Administrateur> getAllAdmins() {
        ArrayList<Administrateur> list = new ArrayList<>();
        String sql = "SELECT * FROM administrateur";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Administrateur(
                    rs.getInt("id_admini"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getInt("id_ad_au")
                ));
            }

        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la récupération de la liste : " + e.getMessage());
        }

        return list;
    }

}






