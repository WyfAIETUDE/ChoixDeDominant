package dao;

import java.sql.*;
import java.util.*;
import java.util.List;
import model.*;
import model.Etudiant;

/**
 * DAO pour la gestion des attributions des dominantes aux étudiants.
 * Gère les opérations d'insertion, de suppression et de consultation 
 * relatives aux choix de dominante faits par les étudiants.
 * 
 * @author  WU Yufan 
 * @version 1.0
 */
public class AttributionDAO extends ConnectionDAO {

    /**
     * Supprime toutes les attributions automatiques (ORDRE_CLASSEMENT = 0).
     */
    public void clearAllAttributions() {
        String sql = "DELETE FROM CHOIXDOMINANTE WHERE ORDRE_CLASSEMENT = 0";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            int deleted = ps.executeUpdate();
            System.out.println("✅ Effacé " + deleted + " Enregistrements d'attribution automatique");
        } catch (SQLException e) {
            System.err.println("❌ Échec de la suppression des enregistrements attribués automatiquement !");
            e.printStackTrace();
        }
    }

    /**
     * Récupère la valeur maximale actuelle de la colonne ID_CHOIX dans la table CHOIXDOMINANTE.
     * 
     * @return la valeur maximale de ID_CHOIX, ou 0 si aucun enregistrement n'existe.
     */
    public int getMaxIdChoix() {
        String sql = "SELECT NVL(MAX(ID_CHOIX), 0) FROM CHOIXDOMINANTE";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("❌ Échec de l'obtention de la valeur maximale de ID_CHOIX !");
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Attribue automatiquement une dominante à un étudiant (ORDRE_CLASSEMENT = 0).
     * 
     * @param idEtudiant l'identifiant de l'étudiant
     * @param idDominante l'identifiant de la dominante
     */
    public void assignEtudiantToDominante(int idEtudiant, int idDominante) {
        String deleteSql = "DELETE FROM CHOIXDOMINANTE WHERE ID_CHOIX_ETU = ? AND ID_CHOIXDOM_DOM = ? AND ORDRE_CLASSEMENT = 0";
        String insertSql = "INSERT INTO CHOIXDOMINANTE (ID_CHOIX, ID_CHOIXDOM_DOM, ORDRE_CLASSEMENT, ID_CHOIX_ETU) VALUES (?, ?, 0, ?)";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement deletePs = con.prepareStatement(deleteSql);
             PreparedStatement insertPs = con.prepareStatement(insertSql)) {

            deletePs.setInt(1, idEtudiant);
            deletePs.setInt(2, idDominante);
            deletePs.executeUpdate();

            int newIdChoix = getMaxIdChoix() + 1;

            insertPs.setInt(1, newIdChoix);
            insertPs.setInt(2, idDominante);
            insertPs.setInt(3, idEtudiant);
            insertPs.executeUpdate();

            System.out.println("✅ Attribution réussie : Etudiant ID = " + idEtudiant + ", Dominante ID = " + idDominante + ", ID_CHOIX = " + newIdChoix);

        } catch (SQLException e) {
            System.err.println("❌ Attribution échouée：Etudiant ID = " + idEtudiant + ", Dominante ID = " + idDominante);
            e.printStackTrace();
        }
    }

    /**
     * Récupère un résumé de la répartition actuelle des dominantes (ORDRE_CLASSEMENT = 0 uniquement).
     * 
     * @return une map dont les clés sont les noms des dominantes et les valeurs les listes d'étudiants.
     */
    public Map<String, List<String>> getDistributionSummary() {
        Map<String, List<String>> map = new HashMap<>();
        String sql =
            "SELECT d.nomdomi, e.nom, e.prenom " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN ETUDIANT e ON c.ID_CHOIX_ETU = e.ID_ETUDIANT " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE c.ORDRE_CLASSEMENT = 0 " +
            "ORDER BY d.nomdomi, e.classement";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String dominante = rs.getString("nomdomi");
                String studentName = rs.getString("nom") + " " + rs.getString("prenom");
                map.computeIfAbsent(dominante, k -> new ArrayList<>()).add(studentName);
            }

        } catch (SQLException e) {
            System.err.println("❌ Échec de la consultation du résumé des attributions !");
            e.printStackTrace();
        }

        return map;
    }

    /**
     * Récupère les choix faits par un étudiant (ORDRE_CLASSEMENT > 0).
     * 
     * @param idEtudiant l'identifiant de l'étudiant
     * @return liste des choix classés de dominante
     */
    public List<String> getStudentChoixById(int idEtudiant) {
        List<String> list = new ArrayList<>();
        String sql =
            "SELECT d.nomdomi, c.ORDRE_CLASSEMENT " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE c.ID_CHOIX_ETU = ? AND c.ORDRE_CLASSEMENT > 0 " +
            "ORDER BY c.ORDRE_CLASSEMENT";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEtudiant);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int ordre = rs.getInt("ORDRE_CLASSEMENT");
                String nomDomi = rs.getString("nomdomi");
                list.add("le " + ordre + " choix： " + nomDomi);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Récupère les détails de tous les choix faits par les étudiants, sans filtrage.
     * 
     * @return une map des dominantes vers une liste de descriptions d'étudiants.
     */
    public Map<String, List<String>> getAllDirectionChoixDetails() {
        Map<String, List<String>> map = new HashMap<>();
        String sql =
            "SELECT d.nomdomi, e.nom, e.prenom, e.classement, e.type, c.ORDRE_CLASSEMENT " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN ETUDIANT e ON c.ID_CHOIX_ETU = e.ID_ETUDIANT " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "ORDER BY d.nomdomi, c.ORDRE_CLASSEMENT";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String dom = rs.getString("nomdomi");
                String info = rs.getString("nom") + " " + rs.getString("prenom")
                            + " - le " + rs.getInt("ORDRE_CLASSEMENT") + " choix"
                            + " - classement：" + rs.getInt("classement")
                            + " - type：" + rs.getString("type");
                map.computeIfAbsent(dom, k -> new ArrayList<>()).add(info);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return map;
    }

    /**
     * Récupère les étudiants ayant choisi une direction donnée.
     * 
     * @param directionName le nom de la dominante
     * @return une liste des étudiants associés à cette dominante
     */
    public List<String> getStudentsForDirection(String directionName) {
        List<String> list = new ArrayList<>();
        String sql =
            "SELECT e.nom, e.prenom, e.classement, e.type, c.ORDRE_CLASSEMENT " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN ETUDIANT e ON c.ID_CHOIX_ETU = e.ID_ETUDIANT " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE d.nomdomi = ? " +
            "ORDER BY c.ORDRE_CLASSEMENT";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, directionName);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String info = rs.getString("nom") + " " + rs.getString("prenom")
                            + " - le " + rs.getInt("ORDRE_CLASSEMENT") + " choix"
                            + " - classement：" + rs.getInt("classement")
                            + " - type：" + rs.getString("type");
                list.add(info);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Attribue un choix à un étudiant avec un ordre donné (manuel).
     * 
     * @param idEtudiant identifiant de l'étudiant
     * @param idDominante identifiant de la dominante
     * @param ordreClassement ordre du choix (1 = premier choix)
     */
    public void assignEtudiantToDominanteWithOrdre(int idEtudiant, int idDominante, int ordreClassement) {
        String deleteSql = "DELETE FROM CHOIXDOMINANTE WHERE ID_CHOIX_ETU = ? AND ID_CHOIXDOM_DOM = ?";
        String insertSql = "INSERT INTO CHOIXDOMINANTE (ID_CHOIX, ID_CHOIXDOM_DOM, ORDRE_CLASSEMENT, ID_CHOIX_ETU) VALUES (?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement deletePs = con.prepareStatement(deleteSql);
             PreparedStatement insertPs = con.prepareStatement(insertSql)) {

            deletePs.setInt(1, idEtudiant);
            deletePs.setInt(2, idDominante);
            deletePs.executeUpdate();

            int newId = getMaxIdChoix() + 1;
            insertPs.setInt(1, newId);
            insertPs.setInt(2, idDominante);
            insertPs.setInt(3, ordreClassement);
            insertPs.setInt(4, idEtudiant);
            insertPs.executeUpdate();

        } catch (SQLException e) {
            System.err.println("❌ Attribution échouée：" + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Vérifie si l'étudiant a soumis des choix manuels (ORDRE_CLASSEMENT > 0).
     * 
     * @param idEtudiant identifiant de l'étudiant
     * @return true si des choix existent, false sinon
     */
    public boolean hasSubmittedChoix(int idEtudiant) {
        String sql = "SELECT COUNT(*) FROM CHOIXDOMINANTE WHERE ID_CHOIX_ETU = ? AND ORDRE_CLASSEMENT > 0";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEtudiant);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Récupère les étudiants groupés par leur premier choix (ORDRE_CLASSEMENT = 1).
     * 
     * @return map des noms de dominantes vers listes d'étudiants
     */
    public Map<String, List<Etudiant>> getStudentsGroupedByFirstChoice() {
        Map<String, List<Etudiant>> map = new HashMap<>();
        String sql =
            "SELECT e.ID_ETUDIANT, e.nom, e.prenom, e.classement, e.type, d.nomdomi " +
            "FROM ETUDIANT e " +
            "JOIN CHOIXDOMINANTE c ON e.ID_ETUDIANT = c.ID_CHOIX_ETU " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE c.ORDRE_CLASSEMENT = 1 " +
            "ORDER BY d.nomdomi, e.classement";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Etudiant etu = new Etudiant();
                etu.setId_etudiant(rs.getInt("ID_ETUDIANT"));
                etu.setNom(rs.getString("nom"));
                etu.setPrenom(rs.getString("prenom"));
                etu.setClassement(rs.getInt("classement"));
                etu.setType(rs.getString("type"));
                String dominante = rs.getString("nomdomi");

                map.computeIfAbsent(dominante, k -> new ArrayList<>()).add(etu);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return map;
    }

    /**
     * Récupère l'ordre de classement d'un choix donné pour un étudiant et dominante.
     * 
     * @param idEtudiant l'identifiant de l'étudiant
     * @param idDominante l'identifiant de la dominante
     * @return l'ordre de classement, ou 1 par défaut
     */
    public int getOrdreClassement(int idEtudiant, int idDominante) {
        String sql = "SELECT ORDRE_CLASSEMENT FROM CHOIXDOMINANTE WHERE ID_CHOIX_ETU = ? AND ID_CHOIXDOM_DOM = ?";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEtudiant);
            ps.setInt(2, idDominante);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("ORDRE_CLASSEMENT");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    /**
     * Supprime les attributions automatiques invalides, c’est-à-dire
     * celles qui ont un doublon dans les choix manuels (ORDRE_CLASSEMENT > 0).
     */
    public void cleanInvalidAutomaticAssignments() {
        String sql = "DELETE FROM CHOIXDOMINANTE WHERE ORDRE_CLASSEMENT = 0 AND EXISTS " +
                     "(SELECT 1 FROM CHOIXDOMINANTE c2 WHERE c2.ID_CHOIX_ETU = CHOIXDOMINANTE.ID_CHOIX_ETU AND c2.ID_CHOIXDOM_DOM = CHOIXDOMINANTE.ID_CHOIXDOM_DOM AND c2.ORDRE_CLASSEMENT > 0)";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            int count = ps.executeUpdate();
            System.out.println("✅ Nombre d'attributions automatiques invalides supprimées : " + count);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Récupère la liste des étudiants uniques pour une dominante, basée sur leur meilleur classement.
     * 
     * @param directionName le nom de la dominante
     * @return liste des étudiants uniques
     */
    public List<String> getUniqueStudentsForDirection(String directionName) {
        List<String> list = new ArrayList<>();
        String sql =
            "SELECT DISTINCT e.nom, e.prenom, e.classement, e.type " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN ETUDIANT e ON c.ID_CHOIX_ETU = e.ID_ETUDIANT " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE d.nomdomi = ? AND c.ORDRE_CLASSEMENT = " +
            "(SELECT MIN(c2.ORDRE_CLASSEMENT) FROM CHOIXDOMINANTE c2 WHERE c2.ID_CHOIX_ETU = e.ID_ETUDIANT) " +
            "ORDER BY e.classement";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, directionName);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String info = rs.getString("nom") + " " + rs.getString("prenom")
                            + " - classement：" + rs.getInt("classement")
                            + " - type：" + rs.getString("type");
                list.add(info);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * Supprime tous les choix initiaux manuels (ORDRE_CLASSEMENT > 0).
     */
    public void deleteOriginalChoix() {
        String sql = "DELETE FROM CHOIXDOMINANTE WHERE ORDRE_CLASSEMENT > 0";
        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            int deleted = ps.executeUpdate();
            System.out.println("✅ " + deleted + " choix initiaux supprimés.");
        } catch (SQLException e) {
            System.err.println("❌ Échec de suppression des choix initiaux !");
            e.printStackTrace();
        }
    }

    /**
     * Récupère la dominante finale attribuée à chaque étudiant (ORDRE_CLASSEMENT = 0).
     * 
     * @return une map des identifiants étudiants vers le nom de la dominante finale
     */
    public Map<Integer, String> getFinalAttributions() {
        Map<Integer, String> map = new HashMap<>();
        String sql =
            "SELECT c.ID_CHOIX_ETU, d.nomdomi " +
            "FROM CHOIXDOMINANTE c " +
            "JOIN DOMINANTE d ON c.ID_CHOIXDOM_DOM = d.ID_DOMINANTE " +
            "WHERE c.ORDRE_CLASSEMENT = 0";

        try (Connection con = DriverManager.getConnection(URL, LOGIN, PASS);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int idEtu = rs.getInt("ID_CHOIX_ETU");
                String dominante = rs.getString("nomdomi");
                map.put(idEtu, dominante);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return map;
    }
}





